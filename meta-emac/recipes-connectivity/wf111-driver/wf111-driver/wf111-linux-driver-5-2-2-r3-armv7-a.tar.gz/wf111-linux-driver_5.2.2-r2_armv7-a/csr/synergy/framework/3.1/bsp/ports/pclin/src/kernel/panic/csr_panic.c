/*****************************************************************************

            (c) Cambridge Silicon Radio Limited 2010
            All rights reserved and confidential information of CSR

            Refer to LICENSE.txt included with this source for details
            on the license terms.

*****************************************************************************/

#include <linux/kernel.h>
#include <linux/version.h>
#include <linux/bug.h>

#include "csr_types.h"
#include "csr_panic.h"

void CsrPanic(CsrUint8 tech, CsrUint16 reason, const char *p)
{
    BUG_ON(1);
}
