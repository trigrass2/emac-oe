#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "define.h"
#include "REL_DEBUG.H"
#include "REL_EC_API.h"


void show_menu(void)
{
	printf("\n");
	printf("0) Terminate this program\n");
	printf("1) Probe I2C Slave Device\n");
	printf("2) Write-Read Operation\n");
	printf("3) Register Read\n");
	printf("4) Register Write\n");
	//Add Ryan.xin 20120223
	/*************************************/
	printf("5) Block Read by offset\n");
	printf("6) Block Write by offset\n");	
	/*************************************/
	printf("7) Get I2C Frequency\n");
	printf("8) Set I2C Frequency\n");
	printf("9) Set I2C Mode (Byte/Word)\n");
	printf("Enter your choice: \n");
}

int main( int argc, char *argv[] )
{
	int done, op, input;
	unsigned long status = 0;
	unsigned long value = 0;
	unsigned long blockSize = 0;
	unsigned long i = 0;
	unsigned long addr = 0;
	unsigned long cmd_off = 0;
	unsigned long read_n = 0;
	unsigned long write_n = 0;
	unsigned char r_buf[32] = {0};
	unsigned char w_buf[32] = {0};
	unsigned char * r_p = NULL;
	unsigned char * w_p = NULL;


	status = EApiLibInitialize();
	if (EAPI_STATUS_SUCCESS != status)
	{
		printf("EApiLibInitialize() failed, error code: 0x%lX.\n", status);
		return -1;
	}
	else
	{
		printf("EApiLibInitialize() OK.\n");
	}

	status = EApiI2CGetBusCap(EAPI_ID_I2C_EXTERNAL, &blockSize);
	if (EAPI_STATUS_SUCCESS != status)
	{
		printf("EapiI2CGetBusCap() failed, error code: 0x%lX.\n", status);
		return -1;
	}
	else
	{		
		printf("External I2C maximum block size is: %ld\n", blockSize);
	}

	done = 0;
	while (! done) {
		show_menu();
		if (scanf("%i", &op) <= 0)
			op = -1;
		
		switch (op) {
		case 0:
			done = 1;
			continue;

		case 1:
			printf("Probe Begin...\n");
			for( i = 0; i < 127; i ++)
			{
				status = EApiI2CProbeDevice(EAPI_ID_I2C_EXTERNAL, i);
				if (EAPI_STATUS_SUCCESS == status)
				{
					printf("7-Bit Address 0x%lX device is exist.\n", i << 1);				
				}				
			}
			printf("Probe Finished.\n");
			status = EAPI_STATUS_SUCCESS;
			break;

		case 2:	
			read_n = 0;
			write_n = 0;

			printf("Please input 7-Bit I2C Addr (HEX):\n");
			if (scanf("%x", &input) <= 0)
				input = 0;

			if( (input > 255) || (input < 0) )
			{
				printf("Addr out of range\n");
				break;
			}
			addr = input;

			printf("Please input data read number:\n");
			if (scanf("%i", &input) <= 0)
				input = 0;
			read_n = input;
			
			if(read_n > 32)
			{
				read_n = 32;
			}
			
			if(read_n < 1)
			{
				r_p = NULL;
			}
			else
			{
				r_p = r_buf;
			}

			printf("Please input data write number:\n");
			if (scanf("%i", &input) <= 0)
				input = 0;
			write_n = input;
			
			if(write_n > 32)
			{
				write_n = 32;
			}		

			if(write_n < 1)
			{
				w_p = NULL;
			}
			else
			{
				w_p = w_buf;
			}

			if(write_n > 0)
			{
				for( i = 0; i < write_n; i ++ )
				{
					printf("Please input write Data %ld value (HEX):\n", i);
					if (scanf("%x", &input) <= 0)
						input = 0;
					
					if(input > 0xFF)
					{
						input = 0xFF;
					}

					*(w_p + i) = input;
				}
			}
			
			status = EApiI2CWriteReadRaw(EAPI_ID_I2C_EXTERNAL, addr, w_p, write_n, r_p, 32, read_n);
			if (EAPI_STATUS_SUCCESS != status)
			{
				printf("EApiI2CWriteReadRaw failed, error code: 0x%lX.\n", status);
				status = -1;
				done = 1;
				continue;
			}
			else
			{
				printf("Write-Read OK.\n");
				if(read_n > 0)
				{
					for( i = 0; i < read_n; i ++ )
					{
						printf("Read Data[%ld] value is: 0x%x\n", i, *(r_p + i) );
					}
				}
			}			
			break;

		case 3:	
			
			printf("Please input 7-Bit I2C Addr (HEX):\n");
			if (scanf("%x", &input) <= 0)
				input = 0;
			
			if( (input > 255) || (input < 0) )
			{
				printf("Addr out of range\n");
				break;
			}
			addr = input;
			
			//Modify Ryan.xin 20120223
			read_n = 1;

			printf("Please input Command/Offset (HEX):\n");
			if (scanf("%x", &input) <= 0)
				input = 0;

			if( (input > 0xFF) || (input < 0) )
			{
				input = 0;
			}

			cmd_off = input;
			
			status = EApiI2CReadTransfer(EAPI_ID_I2C_EXTERNAL, addr, cmd_off, r_buf, 32, read_n);
			if (EAPI_STATUS_SUCCESS != status)
			{
				printf("EApiI2CReadTransfer failed, error code: 0x%lX.\n", status);
				status = -1;
				done = 1;
				continue;
			}
			else
			{
				printf("Read Transfer OK.\n");
				for( i = 0; i < read_n; i ++ )
				{
					printf("Read Data[%02ld] value is: 0x%02x\n", i, r_buf[i]  );
				}
			}			
			break;


		case 4:				
			printf("Please input 7-Bit I2C Addr (HEX):\n");
			if (scanf("%x", &input) <= 0)
				input = 0;
			
			if( (input > 255) || (input < 0) )
			{
				printf("Addr out of range\n");
				break;
			}
			addr = input;			
			
			//Modify Ryan.xin 20120223
			write_n = 1;
		
			if(write_n > 0)
			{
				for( i = 0; i < write_n; i ++ )
				{
					printf("Please input write Data %ld value (HEX):\n", i);
					if (scanf("%x", &input) <= 0)
						input = 0;
					
					if(input > 0xFF)
					{
						input = 0xFF;
					}
					
					w_buf[i] = input;
				}
			}

			printf("Please input Command/Offset (HEX):\n");
			if (scanf("%x", &input) <= 0)
				input = 0;
			
			if( (input > 0xFF) || (input < 0) )
			{
				input = 0;
			}
			
			cmd_off = input;
			
			status = EApiI2CWriteTransfer(EAPI_ID_I2C_EXTERNAL, addr, cmd_off, w_buf, write_n);
			if (EAPI_STATUS_SUCCESS != status)
			{
				printf("EApiI2CWriteTransfer failed, error code: 0x%lX.\n", status);
				status = -1;
				done = 1;
				continue;
			}
			else
			{
				printf("Write Transfer OK.\n");				
			}			
			break;
		//Add Ryan.xin 20120223
		//Block szie 32 byte, if you want to change size, please modify the buffer size
		/************************************************/
		case 5:
			printf("Please input 7-Bit I2C Addr (HEX):\n");
			if (scanf("%x", &input) <= 0)
				input = 0;
			
			if( (input > 255) || (input < 0) )
			{
				printf("Addr out of range\n");
				break;
			}
			addr = input;

			printf("Please input data read number:\n");
			if (scanf("%i", &input) <= 0)
				input = 0;
			read_n = input;
			
			if(read_n > 32)
			{
				read_n = 32;
			}
			
			printf("Please input Command/Offset (HEX):\n");
			if (scanf("%x", &input) <= 0)
				input = 0;
			
			if( (input > 0xFF) || (input < 0) )
			{
				input = 0;
			}
			
			cmd_off = input;
			
			status = EApiI2CReadTransfer(EAPI_ID_I2C_EXTERNAL, addr, cmd_off, r_buf, 32, read_n);
			if (EAPI_STATUS_SUCCESS != status)
			{
				printf("EApiI2CReadTransfer failed, error code: 0x%lX.\n", status);
				status = -1;
				done = 1;
				continue;
			}
			else
			{
				printf("Read Transfer OK.\n");
				for( i = 0; i < read_n; i ++ )
				{
					printf("Read Data[%02ld] value is: 0x%02x\n", i, r_buf[i]  );
				}
			}			
			break;
		case 6:
			printf("Please input 7-Bit I2C Addr (HEX):\n");
			if (scanf("%x", &input) <= 0)
				input = 0;
			
			if( (input > 255) || (input < 0) )
			{
				printf("Addr out of range\n");
				break;
			}
			addr = input;			

			printf("Please input data write number:\n");
			if (scanf("%i", &input) <= 0)
				input = 0;
			write_n = input;
			
			if(write_n > 32)
			{
				write_n = 32;
			}						
			if(write_n > 0)
			{
				for( i = 0; i < write_n; i ++ )
				{
					printf("Please input write Data %ld value (HEX):\n", i);
					if (scanf("%x", &input) <= 0)
						input = 0;
					
					if(input > 0xFF)
					{
						input = 0xFF;
					}
					
					w_buf[i] = input;
				}
			}
			
			printf("Please input Command/Offset (HEX):\n");
			if (scanf("%x", &input) <= 0)
				input = 0;
			
			if( (input > 0xFF) || (input < 0) )
			{
				input = 0;
			}
			
			cmd_off = input;
			
			status = EApiI2CWriteTransfer(EAPI_ID_I2C_EXTERNAL, addr, cmd_off, w_buf, write_n);
			if (EAPI_STATUS_SUCCESS != status)
			{
				printf("EApiI2CWriteTransfer failed, error code: 0x%lX.\n", status);
				status = -1;
				done = 1;
				continue;
			}
			else
			{
				printf("Write Transfer OK.\n");				
			}			
			break;
	
		/************************************************************/
		case 7:	
			status = EApiGetI2CSMBFrequency(EAPI_ID_I2C_EXTERNAL, &value);
			if (EAPI_STATUS_SUCCESS != status)
			{
				printf("EApiGetI2CSMBFrequency failed, error code: 0x%lX.\n", status);
				status = -1;
				done = 1;
				continue;
			}
			else
			{
				printf("Current Frequency is %ld.\n", value);
				
			}
			break;

		case 8:	
			printf("Please choose the I2C Frequency you want:(1:50 Hz, 2:100 Hz, 3:400 Hz)\n");
			if (scanf("%i", &input) <= 0)
				break;
			
			if( (input != 1) && (input!= 2)  && (input!= 3))
			{
				printf("Input error\n");
				break;
			}
			else
			{
				if (input == 1)
					input = 50;
				else if (input == 2)
					input = 100;
				else if (input == 3)
					input = 400;
			}

			status = EApiSetI2CSMBFrequency(EAPI_ID_I2C_EXTERNAL, input);
			if (EAPI_STATUS_SUCCESS != status)
			{
				printf("EApiSetI2CSMBFrequency failed, error code: 0x%lX.\n", status);
				status = -1;
				done = 1;
				continue;
			}
			else
			{
				printf("Set Frequency OK.\n");				
				
			}
			break;

		case 9:	
			printf("Please choose the I2C Mode you want:(1:Byte, 2:Word)\n");
			if (scanf("%i", &input) <= 0)
				break;
			
			if( (input != 1) && (input!= 2) )
			{
				printf("Input error\n");
				break;
			}
			status = EApiSetI2CMode(input);
			if (EAPI_STATUS_SUCCESS != status)
			{
				printf("EApiSetI2CMode failed, error code: 0x%lX.\n", status);
				status = -1;
				done = 1;
				continue;
			}	
			break;


		default:
			printf("\nUnknown choice!\n\n");
			continue;
		}

		if (EAPI_STATUS_SUCCESS != status) 
		{
			status = EApiLibUnInitialize();
			if (EAPI_STATUS_SUCCESS != status)
			{
				printf("EApiLibUnInitialize() failed, error code: 0x%lX.\n", status);
				return -1;
			}
			else
			{
				printf("EApiLibUnInitialize() OK.\r\n");
			}	return -1;
		}
	}	

	status = EApiLibUnInitialize();
	if (EAPI_STATUS_SUCCESS != status)
	{
		printf("EApiLibUnInitialize() failed, error code: 0x%lX.\n", status);
		return -1;
	}
	else
	{
		printf("EApiLibUnInitialize() OK.\r\n");
	}	
	
	return 0;
}
