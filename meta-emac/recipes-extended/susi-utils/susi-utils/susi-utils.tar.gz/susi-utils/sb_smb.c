#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "define.h"
#include "REL_DEBUG.H"
#include "REL_EC_API.h"


void show_menu(void)
{
	printf("\n");
	printf("0) Terminate this program\n");
	printf("1) Scan exist device\n");	
	printf("2) Quick read\n");
	printf("3) Quick write\n");	
	printf("4) Byte data read\n");
	printf("5) Byte data write\n");
	printf("6) Word data read\n");
	printf("7) Word data write\n");
	printf("8) Block data read\n");
	printf("9) Block data write\n");
	printf("Enter your choice: \n");
}

int scan_dev()
{
	int i;
	unsigned long status;

	printf("Scan South-Bridge SMBus devices...\n");

	for(i = 0; i < 0x7F; i ++)
	{
		status = SusiSMBusScanDevice( i );
		if(EAPI_STATUS_SUCCESS == status)
		{
			printf("7-Bit Address 0x%02X device is exist.\n", i << 1);
		}		
	}

	return 0;
}

int quick_read()
{
	int data;
	unsigned char Addr;

	printf("Please input target device address (HEX):\n");
	scanf("%x", &data);
	Addr = (unsigned char) data;

	if( EAPI_STATUS_SUCCESS == SusiSMBusReadQuick(Addr) )
	{
		printf("Quick Read OK.\n");

	}
	else
	{
		printf("Quick Read failed!!!\n");
	}

	return 0;
}

int quick_write()
{
	int data;
	unsigned char Addr;
	
	printf("Please input target device address (HEX):\n");
	scanf("%x", &data);
	Addr = (unsigned char) data;
	
	if( EAPI_STATUS_SUCCESS == SusiSMBusWriteQuick(Addr) )
	{
		printf("Quick Write OK.\n");

	}
	else
	{
		printf("Quick Write failed!!!\n");
	}
	
	return 0;
}

int byte_read()
{
	int data;
	unsigned char Addr;
	unsigned char byOffset;
	unsigned char byData;
	
	printf("Please input target device address (HEX):\n");
	scanf("%x", &data);
	Addr = (unsigned char) data;
	
	printf("Please input operation command/offset (HEX):\n");
	scanf("%x", &data);
	byOffset = (unsigned char) data;
	
	if( EAPI_STATUS_SUCCESS == SusiSMBusReadByte(Addr, byOffset, &byData ) )
	{
		printf("Byte read OK. Data: 0x%X\n", byData);
	}
	else
	{
		printf("Byte read failed!!!\n");
	}
	
	return 0;
}

int byte_write()
{
	int data;
	unsigned char Addr;
	unsigned char byOffset;
	unsigned char byData;
	
	printf("Please input target device address (HEX):\n");
	scanf("%x", &data);
	Addr = (unsigned char) data;
	
	printf("Please input operation command/offset (HEX):\n");
	scanf("%x", &data);
	byOffset = (unsigned char) data;

	printf("Please input byte data value (HEX):\n");
	scanf("%x", &data);
	byData = (unsigned char) data;
	
	if( EAPI_STATUS_SUCCESS == SusiSMBusWriteByte( Addr, byOffset, byData ) )
	{
		printf("Byte write OK.\n" );
	}
	else
	{
		printf("Byte write failed!!!\n");
	}
	
	return 0;
}

int word_read()
{
	int data;
	unsigned char Addr;
	unsigned char byOffset;
	unsigned short wData;
	
	printf("Please input target device address (HEX):\n");
	scanf("%x", &data);
	Addr = (unsigned char) data;
	
	printf("Please input operation command/offset (HEX):\n");
	scanf("%x", &data);
	byOffset = (unsigned char) data;
	
	if( EAPI_STATUS_SUCCESS == SusiSMBusReadWord( Addr, byOffset, &wData ) )
	{
		printf("Word read OK. Data: 0x%X\n", wData);
	}
	else
	{
		printf("Word read failed!!!\n");
	}
	
	return 0;
}

int word_write()
{
	int data;
	unsigned char Addr;
	unsigned char byOffset;
	unsigned short wData;
	
	printf("Please input target device address (HEX):\n");
	scanf("%x", &data);
	Addr = (unsigned char) data;
	
	printf("Please input operation command/offset (HEX):\n");
	scanf("%x", &data);
	byOffset = (unsigned char) data;
	
	printf("Please input word data value (HEX):\n");
	scanf("%x", &data);
	wData = (unsigned short) data;
	
	if( EAPI_STATUS_SUCCESS == SusiSMBusWriteWord( Addr, byOffset, wData ) )
	{
		printf("Word write OK.\n" );
	}
	else
	{
		printf("Word write failed!!!\n");
	}
	
	return 0;
}

int block_read(void)
{
	int data, count, index;
	unsigned char Addr;
	unsigned char byOffset;
	unsigned char *storage;
	unsigned char read_n = 0;
	
	printf("Please input target device address (HEX):\n");
	scanf("%x", &data);
	Addr = (unsigned char) data;
	
	printf("Please input operation command/offset (HEX):\n");
	scanf("%x", &data);
	byOffset = (unsigned char) data;
	
	printf("Please input bytes read count:\n");
	scanf("%i", &count);

	if(count < 1)
	{
		count  = 10;
	}

	storage = (unsigned char*) malloc(count);
	
	read_n = (unsigned char)count;
	if( EAPI_STATUS_SUCCESS == SusiSMBusReadBlock(Addr, byOffset, storage, &read_n) )
	{
		printf("Data read: ");
		for (index = 0; index < count; index++)
		{
			printf(" %02x", storage[index]);
		}

		printf("\nBlock data read OK.\n");		
	}
	else
	{
		printf("\nBlock data read failed!!!\n");	
	}	

	free(storage);

	return 0;
}

int block_write(void)
{
	int data, count, index;
	unsigned char Addr;
	unsigned char byOffset;
	unsigned char *storage;
	
	printf("Please input target device address (HEX):\n");
	scanf("%x", &data);
	Addr = (unsigned char) data;
	
	printf("Please input operation command/offset (HEX):\n");
	scanf("%x", &data);
	byOffset = (unsigned char) data;
	
	printf("Please input bytes write count:\n");
	scanf("%i", &count);
	
	if(count < 1)
	{
		count  = 10;
	}
	
	storage = (unsigned char*) malloc(count);

	for (index = 0; index < count; index++)
	{
		printf("Please input NO. %d byte data value (HEX):\n", index);
		scanf("%x", &data);

		storage[index] = (unsigned char) data;
	}
	
	if( EAPI_STATUS_SUCCESS == SusiSMBusWriteBlock(Addr, byOffset, storage, count) )
	{		
		printf("\nBlock data write OK.\n");		
	}
	else
	{
		printf("\nBlock data write failed!!!\n");	
	}	
	
	free(storage);
	
	return 0;
}

int main( int argc, char *argv[] )
{
	int done, op;
	unsigned long status = 0;
	int result = 0;

	status = EApiLibInitialize();
	if (EAPI_STATUS_SUCCESS != status)
	{
		printf("EApiLibInitialize() failed, error code: 0x%lX.\n", status);
		return -1;
	}
	else
	{
		printf("EApiLibInitialize() OK.\n");
	}

	done = 0;	
	while (!done)
	{
		show_menu();
		
		scanf("%i", &op);
		
		switch (op)
		{
		case 0:
			done = 1;
			continue;
		case 1:
			result = scan_dev();
			break;
		case 2:
			result = quick_read();
			break;
		case 3:
			result = quick_write();
			break;
		case 4:
			result = byte_read();
			break;
		case 5:
			result = byte_write();
			break;
		case 6:
			result = word_read();
			break;
		case 7:
			result = word_write();
			break;
		case 8:
			result = block_read();
			break;
		case 9:
			result = block_write();
			break;
		default:
			printf("\nUnknown choice!\n");	
			break;
		} /*switch (op)*/

		if(done != 1 && result < 0) 
		{
			status = EApiLibUnInitialize();
			if (EAPI_STATUS_SUCCESS != status)
			{
				printf("EApiLibUnInitialize() failed, error code: 0x%lX.\n", status);
				return -1;
			}
			else
			{
				printf("EApiLibUnInitialize() OK.\n");
			}
			
			return -1;
		}

	} /*while (!done)*/
	
	status = EApiLibUnInitialize();
	if (EAPI_STATUS_SUCCESS != status)
	{
		printf("EApiLibUnInitialize() failed, error code: 0x%lX.\n", status);
		return -1;
	}
	else
	{
		printf("EApiLibUnInitialize() OK.\n");
	}

	return 0;
}
