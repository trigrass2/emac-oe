#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "define.h"
#include "REL_DEBUG.H"
#include "REL_EC_API.h"



int show_lockstatus()
{
	if( EAPI_STATUS_SUCCESS == SusiStorageAreaIsLocked(0, 0) )
	{
		printf("Storage Area is locked now, and can not write or erase data.\n");
	}
	else
	{
		printf("Storage Area is unlocked now, and can write or erase data.\n");
	}
	
	return 0;
}

int lock_area()
{
	char str[100] = {0};

	getc(stdin);
	printf("Please input the security key to lock:\n");
	scanf("%[^\n]%*c", str);
	if ( EAPI_STATUS_SUCCESS == SusiStorageAreaLock(0, 0, str, strlen(str)) )
	{
		printf("Lock Ok.\n");
	}
	else
	{
		printf("Lock failed!!!\n");
	}
	
	return 0;	
}

int unlock_area()
{
	char str[100] = {0};

	getc(stdin);
	printf("Please input the security key to unlock:\n");
	scanf("%[^\n]%*c", str);
	if ( EAPI_STATUS_SUCCESS == SusiStorageAreaUnlock(0, 0, str, strlen(str)) )
	{
		printf("Unlock Ok.\n");
	}
	else
	{
		printf("Unlock failed!!!\n");
	}
	
	return 0;	
}

int erase_area()
{
	int data;
	unsigned long status = 0;
	unsigned long offset;
	unsigned long len;
	unsigned char byData[64];
	unsigned long i;
	
	printf("Offset:\n");
	if (scanf("%i", &data) <= 0)
		data = 0;	
	offset = (unsigned long) data;
	
	printf("Length:\n");
	if (scanf("%i", &data) <= 0)
		data = 10;	
	len = (unsigned long) data;
	
	for( i = 0; i < len; i ++ )
	{
		data = 0x0;	
		byData[i] = (unsigned char) data;
	}
	
	status = EApiStorageAreaWrite(EAPI_ID_STORAGE_STD, offset, byData, len);
	if (EAPI_STATUS_SUCCESS != status)
	{
		printf("Erase storage failed, error code: 0x%lX.\n", status);
	}
	else
	{
		printf("Erase storage OK. (Offset: %ld, Length: %ld).\n", offset, len);
	}	
	
	return 0;
}

int read_area()
{
	int data;
	unsigned long status = 0;
	unsigned long offset;
	unsigned long len;
	unsigned char byData[65];
	
	printf("Offset:\n");
	if (scanf("%i", &data) <= 0)
		data = 0;	
	offset = (unsigned long) data;
	
	printf("Length:\n");
	if (scanf("%i", &data) <= 0)	
		data = 10;
	
	len = (unsigned long) data;

	if(offset + len > 64)
	{
		printf("Input wrong: %ld + %ld > 64\n", offset, len);
		return -1;
	}

	status = EApiStorageAreaRead(EAPI_ID_STORAGE_STD, offset, byData, len, len);
	if (EAPI_STATUS_SUCCESS != status)
	{
		printf("Read storage failed, error code: 0x%lX.\n", status);
	}
	else
	{
		printf("Read storage OK.\n");

		byData[offset + len] = '\0';

		printf("From Offset %ld, read %ld data, content is: %s\n", offset, len, byData);
	}	
	
	return 0;
}

int write_area()
{
	int data;
	unsigned long status = 0;
	unsigned long offset;
	unsigned long len;
	unsigned char byData[100];
	
	printf("Offset:\n");
	if (scanf("%i", &data) <= 0)
		data = 0;	
	offset = (unsigned long) data;

	printf("Length:\n");
	if (scanf("%i", &data) <= 0)
		data = 0;	
	len = (unsigned long) data;

	getc(stdin);

	printf("Please input a string to storage area:\n");
	scanf("%[^\n]%*c", byData);
	byData[len] = 0;
	
	if(offset + len > 64)
	{
		printf("Input wrong: %ld + %ld > 64\n", offset, len);
		return -1;
	}

	byData[len] = '\0';

	status = EApiStorageAreaWrite(EAPI_ID_STORAGE_STD, offset, byData, len);
	if (EAPI_STATUS_SUCCESS != status)
	{
		printf("Write storage failed, error code: 0x%lX.\n", status);
	}
	else
	{
		printf("Write storage OK. (Offset: %ld, write content: %s).\n", offset, byData);
	}	

	return 0;
}
//Add Ryan.xin 20120223
int read_byte()
{
	int data;
	unsigned long status = 0;
	unsigned long offset;
	unsigned long len;
	unsigned char byData[64];
	unsigned long i = 0;
	
	printf("Offset:\n");
	if (scanf("%i", &data) <= 0)
		data = 0;	
	offset = (unsigned long) data;

	len = 1UL;
	
	status = EApiStorageAreaRead(EAPI_ID_STORAGE_STD, offset, byData, len, len);
	if (EAPI_STATUS_SUCCESS != status)
	{
		printf("Read storage failed, error code: 0x%lX.\n", status);
	}
	else
	{
		printf("Read storage OK.\n");
		printf("Offset %ld data: 0x%X\r\n", offset+i, byData[i]);
	}	
	
	return 0;
}

int write_byte()
{
	int data;
	unsigned long status = 0;
	unsigned long offset;
	unsigned long len;
	unsigned char byData[64];
	unsigned long i = 0;
	
	printf("Offset:\n");
	if (scanf("%i", &data) <= 0)
		data = 0;	
	offset = (unsigned long) data;
	
	len = 1UL;
	
	printf("Please input offset %ld data (HEX):\n", offset+i);
	if (scanf("%x", &data) <= 0)
		data = 0xFF;	
	byData[i] = (unsigned char) data;
	
	status = EApiStorageAreaWrite(EAPI_ID_STORAGE_STD, offset, byData, len);
	if (EAPI_STATUS_SUCCESS != status)
	{
		printf("Write storage failed, error code: 0x%lX.\n", status);
	}
	else
	{
		printf("Write storage OK. (Offset: %ld, Length: %ld).\n", offset, len);
	}	
	
	return 0;
}
/**************************************************/
void show_menu(void)
{
	printf("\n");
	printf("0) Terminate this program\n");
	printf("1) Show Lock status\n");	
	printf("2) Lock Storage Area\n");		
	printf("3) Unlock Storage Area\n");
	printf("4) Read data(Byte)\n");
	printf("5) Write data(Byte)\n");
	//Add Ryan.xin 20120223
	/***********************************/
	printf("6) Read data (string)\n");
	printf("7) Write data (string)\n");
	printf("8) Erase data\n");
	/***********************************/
	printf("Enter your choice: \n");
}

int main( int argc, char *argv[] )
{
	int done, op;
	int result = 0;
	unsigned long status = 0;
	unsigned long storageSize = 0;
	unsigned long blockLength = 0;


	status = EApiLibInitialize();
	if (EAPI_STATUS_SUCCESS != status)
	{
		printf("EApiLibInitialize() failed, error code: 0x%lX.\n", status);
		return -1;
	}
	else
	{
		printf("EApiLibInitialize() OK.\n");
	}

	status = EApiStorageCap(EAPI_ID_STORAGE_STD, &storageSize, &blockLength);
	if (EAPI_STATUS_SUCCESS != status)
	{
		printf("EApiStorageCap() failed, error code: 0x%lX.\n", status);
		return -1;
	}
	else
	{
		printf("Storage size: %ld\n", storageSize);
		printf("Block length: %ld\n", blockLength);
	}

	done = 0;
	while (! done) {
		show_menu();
		if (scanf("%i", &op) <= 0)
			op = -1;
		
		switch (op) {
		case 0:
			done = 1;
			continue;
		case 1:
			result = show_lockstatus();
			break;
		case 2:
			result = lock_area();
			break;
		case 3:
			result = unlock_area();
			break;
		case 4:
			result = read_byte();
			break;
		case 5:
			result = write_byte();
			break;
		case 6:
			result = read_area();
			break;
		case 7:
			result = write_area();
			break;
		case 8:
			result = erase_area();
			break;
		default:
			printf("\nUnknown choice!\n\n");
			continue;
		}

		if(done != 1 && result < 0) 
		{
			status = EApiLibUnInitialize();
			if (EAPI_STATUS_SUCCESS != status)
			{
				printf("EApiLibUnInitialize() failed, error code: 0x%lX.\n", status);
				return -1;
			}
			else
			{
				printf("EApiLibUnInitialize() OK.\n");
			}
			
			return -1;
		}
	}	

	status = EApiLibUnInitialize();
	if (EAPI_STATUS_SUCCESS != status)
	{
		printf("EApiLibUnInitialize() failed, error code: 0x%lX.\n", status);
		return -1;
	}
	else
	{
		printf("EApiLibUnInitialize() OK.\r\n");
	}	
	
	return 0;
}
