#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "define.h"
#include "REL_DEBUG.H"
#include "REL_EC_API.h"


void show_menu(void)
{
	printf("\n");
	printf("0) Terminate this program\n");
	printf("1) Get LFP Status\n");
	printf("2) Set LFP Status\n");
	//Add Ryan.xin 20120224
	printf("3) Set LFP Frequency value\n");
	printf("4) Set LFP Polarity Status\n");
	printf("5) Get LTP Brightness value by ACPI\n");
	printf("6) Set LTP Brightness value by ACPI\n");
	printf("7) Get LTP Brightness value by PWM\n");
	printf("8) Set LTP Brightness value by PWM\n");	
	printf("Enter your choice: \n");
}

unsigned long get_id_num(int* input)
{
	unsigned long id;

	switch(*input)
	{
	case 1:
		id = EAPI_ID_BACKLIGHT_1;
		break;
	case 2:
		id = EAPI_ID_BACKLIGHT_2;
		break;
	case 3:
		id = EAPI_ID_BACKLIGHT_3;
		break;
	default:
		*input = 1;
		id = EAPI_ID_BACKLIGHT_1;
		break;				
	}
	
	return  id;
}

int main( int argc, char *argv[] )
{
	int done, op, input, input1;
	unsigned long status = 0;
	unsigned long val = 0;
	unsigned long id = 0;

	status = EApiLibInitialize();
	if (EAPI_STATUS_SUCCESS != status)
	{
		printf("EApiLibInitialize() failed, error code: 0x%lX.\n", status);
		return -1;
	}
	else
	{
		printf("EApiLibInitialize() OK.\n");
	}

	done = 0;
	input = 1;
	while (! done) {
		show_menu();
		if (scanf("%i", &op) <= 0)
			op = -1;
		
		switch (op) {
		case 0:
			done = 1;
			continue;

		case 1:	
			/*printf("Please input LFP number (1, 2, 3):\n");
			if (scanf("%i", &input) <= 0)
				input = 1;
			
			id = get_id_num(&input);*/
			id = EAPI_ID_BACKLIGHT_1;
			status = EApiVgaGetBacklightEnable(id, &val);
			if (EAPI_STATUS_SUCCESS != status)
			{
				printf("Get LFP %d status failed, error code: 0x%lX.\n", input, status);
				status = -1;
				done = 1;
				continue;
			}
			else
			{
				printf("LFP %d status: %s\n", input, (val==EAPI_BACKLIGHT_SET_ON)?"ON":"OFF");
			}
			break;

		case 2:
			/*printf("Please input LFP number (1, 2, 3):\n");
			if (scanf("%i", &input) <= 0)
				input = 1;			
			id = get_id_num(&input);*/
			id = EAPI_ID_BACKLIGHT_1;

			printf("Please input LFP status (0: OFF, 1:ON):\n");
			if (scanf("%i", &input1) <= 0)
				input1 = 1;
			
			status = EApiVgaSetBacklightEnable(id, input1?EAPI_BACKLIGHT_SET_ON:EAPI_BACKLIGHT_SET_OFF);
			if (EAPI_STATUS_SUCCESS != status)
			{
				printf("Set LFP %d status failed, error code: 0x%lX.\n", input, status);
				status = -1;
				done = 1;
				continue;
			}
			else
			{
				printf("Set LFP %d status %s OK.\n", input, input1?"ON":"OFF");
			}			
			break;
		case 3:
			id = EAPI_ID_BACKLIGHT_1;
			printf("Please input LFP Frequency values (0 ~ 1000 KHz):\n");
			if (scanf("%i", &input1) <= 0)
				input1 = 1;
			
			val = (unsigned long)input1 * 1000;
			if( (val < 0) || (val > 1000000) )
			{
				val = 1000;
			}
			status = EApiVgaSetFrequency(id, val);
			if (EAPI_STATUS_SUCCESS != status)
			{
				printf("Set LFP %d Frequency with %d KHz failed, error code: 0x%lX.\n", input, input1, status);
				status = -1;
				done = 1;
				continue;
			}
			else
			{
				printf("Set LFP %d Frequency with %d KHz OK.\n", input, input1);
			}	
			break;
		case 4:
			id = EAPI_ID_BACKLIGHT_1;
			printf("Please input LFP Polarity values (0: Non-Invert, 1:Invert):\n");
			if (scanf("%i", &input1) <= 0)
				input1 = 1;
			
			status = EApiVgaSetPolarity(id, input1?(ULONG)0:(ULONG)1);
			if (EAPI_STATUS_SUCCESS != status)
			{
				printf("Set LFP %d Polarity as %d failed, error code: 0x%lX.\n", input, input1?"Invert":"Non-Invert", status);
				status = -1;
				done = 1;
				continue;
			}
			else
			{
				printf("Set LFP %d Polarity as %s OK.\n", input, input1?"Invert":"Non-Invert");
			}	
			break;
		case 5:
			id = EAPI_ID_BACKLIGHT_1;
			status = EApiVgaGetBacklightLevel(id, &val);
			if (EAPI_STATUS_SUCCESS != status)
			{
				printf("Get LFP Level %d failed, error code: 0x%lX.\n", input, status);
				status = -1;
				done = 1;
				continue;
			}
			else
			{
				printf("Get LFP %d Level: %ld\n", input, val);
			}
			break;
		case 6:
			id = EAPI_ID_BACKLIGHT_1;
			printf("Please input LFP Level values(0 ~ 9):\n");
			if (scanf("%i", &input1) <= 0)
				input1 = 1;
			val = input1;
			if( (val < 0) || (val > 9) )
			{
				val = 5;
			}
			status = EApiVgaSetBacklightLevel(id, val);
			if (EAPI_STATUS_SUCCESS != status)
			{
				printf("Set LFP Level %d failed, error code: 0x%lX.\n", input, status);
				status = -1;
				done = 1;
				continue;
			}
			else
			{
				printf("Set LFP %d Level %ld OK.\n", input, val);
			}
			break;
		case 7:
			/*printf("Please input LFP number (1, 2, 3):\n");
			if (scanf("%i", &input) <= 0)
				input = 1;
			
			id = get_id_num(&input);*/
			id = EAPI_ID_BACKLIGHT_1;
			status = EApiVgaGetBacklightBrightness(id, &val);
			if (EAPI_STATUS_SUCCESS != status)
			{
				printf("Get LFP brightness %d failed, error code: 0x%lX.\n", input, status);
				status = -1;
				done = 1;
				continue;
			}
			else
			{
				printf("Get LFP %d brightness: %ld%%\n", input, val);
			}
			break;

		case 8:
			/*printf("Please input LFP number (1, 2, 3):\n");
			if (scanf("%i", &input) <= 0)
				input = 1;			
			id = get_id_num(&input);*/

			id = EAPI_ID_BACKLIGHT_1;
			
			printf("Please input LFP brightness value (0 ~ 100):\n");
			if (scanf("%i", &input1) <= 0)
				input1 = 1;

			val = input1;
			if( (val < 0) || (val > 100) )
			{
				val = 50;
			}
			
			status = EApiVgaSetBacklightBrightness(id, val);
			if (EAPI_STATUS_SUCCESS != status)
			{
				printf("Set LFP brightness %d failed, error code: 0x%lX.\n", input, status);
				status = -1;
				done = 1;
				continue;
			}
			else
			{
				printf("Set LFP %d brightness %ld%% OK.\n", input, val);
			}
			break;

		default:
			printf("\nUnknown choice!\n\n");
			continue;
		}

		if (EAPI_STATUS_SUCCESS != status) 
		{
			status = EApiLibUnInitialize();
			if (EAPI_STATUS_SUCCESS != status)
			{
				printf("EApiLibUnInitialize() failed, error code: 0x%lX.\n", status);
				return -1;
			}
			else
			{
				printf("EApiLibUnInitialize() OK.\r\n");
			}	return -1;
		}
	}	

	status = EApiLibUnInitialize();
	if (EAPI_STATUS_SUCCESS != status)
	{
		printf("EApiLibUnInitialize() failed, error code: 0x%lX.\n", status);
		return -1;
	}
	else
	{
		printf("EApiLibUnInitialize() OK.\r\n");
	}	
	
	return 0;
}
