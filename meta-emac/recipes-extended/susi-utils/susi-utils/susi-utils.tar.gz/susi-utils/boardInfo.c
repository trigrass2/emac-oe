#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "define.h"
#include "REL_DEBUG.H"
#include "REL_EC_API.h"


int main( int argc, char *argv[] )
{
	unsigned long status = 0;
	unsigned long len = 0;
	char str[16] = {0};


	status = EApiLibInitialize();
	if (EAPI_STATUS_SUCCESS != status)
	{
		printf("EApiLibInitialize() failed, error code: 0x%lX.\n", status);
		return -1;
	}
	else
	{
		printf("EApiLibInitialize() OK.\n");
	}

	status = EApiBoardGetStringA(EAPI_ID_BOARD_MANUFACTURER_STR, str, &len);
	if (EAPI_STATUS_SUCCESS != status)
	{
		printf("Get manufacture failed, error code: 0x%lX.\n", status);
		return -1;
	}
	else
	{
		printf("Manufacture: %s", str);
	}

	status = EApiBoardGetStringA(EAPI_ID_BOARD_NAME_STR, str, &len);
	if (EAPI_STATUS_SUCCESS != status)
	{
		printf("Get board name failed, error code: 0x%lX.\n", status);
		return -1;
	}
	else
	{
		printf("Board name: %s\n", str);
	}

	status = EApiBoardGetStringA(EAPI_ID_BOARD_SERIAL_STR, str, &len);
	if (EAPI_STATUS_SUCCESS != status)
	{
		printf("Get serial number failed, error code: 0x%lX.\n", status);
		return -1;
	}
	else
	{
		printf("Serial number: %s", str);
	}	

	status = EApiBoardGetStringA(EAPI_ID_BOARD_BIOS_REVISION_STR, str, &len);
	if (EAPI_STATUS_SUCCESS != status)
	{
		printf("Get BIOS revision failed, error code: 0x%lX.\n", status);
		return -1;
	}
	else
	{
		printf("BIOS revision: %s\n", str);
	}

	status = EApiBoardGetStringA(EAPI_ID_BOARD_PLATFORM_TYPE_STR, str, &len);
	if (EAPI_STATUS_SUCCESS != status)
	{
		printf("Get platform ID failed, error code: 0x%lX.\n", status);
		return -1;
	}
	else
	{
		printf("Platform ID: %s", str);
	}

	status = EApiLibUnInitialize();
	if (EAPI_STATUS_SUCCESS != status)
	{
		printf("EApiLibUnInitialize() failed, error code: 0x%lX.\n", status);
		return -1;
	}
	else
	{
		printf("EApiLibUnInitialize() OK.\n");
	}
	
	
	return 0;
}
