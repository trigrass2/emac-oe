#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "define.h"
#include "REL_DEBUG.H"
#include "REL_EC_API.h"

void ConvertToGeneralVersionNumberFormat(ULONG general_ver_num)
{
	char major_version = 0;
	char minor_version = 0;
	short build_number = 0;

	major_version = (char)(general_ver_num >> 24);
	minor_version = (char)(general_ver_num >> 16);
	build_number = (short)(general_ver_num & 0x0000FFFF);

	printf("%d.%d.%d\n", major_version, minor_version, build_number);
}

void ConvertToSpecificationVersionNumberFormat(ULONG spec_ver_num)
{
	char version = 0;
	char revision = 0;

	version = (char)(spec_ver_num >> 24);
	revision = (char)(spec_ver_num >> 16);

	printf("%d,%d\n", version, revision);
}

void UnCompressASCIIPNPID(ULONG pnpid)
{
	unsigned short ascii_part = 0;
	unsigned short vendor_specific_id = 0;
	unsigned char low_byte = 0;
	unsigned char high_byte = 0;
	unsigned char first_char_pos = 0;
	unsigned char second_char_pos_high_part = 0;
	unsigned char second_char_pos_low_part = 0;
	unsigned char second_char_pos = 0;
	unsigned char third_char_pos = 0;

	ascii_part = (unsigned short)((pnpid >> 12) & 0X0000FFFF);
	low_byte = (unsigned char)(ascii_part & 0X00FF);
	high_byte = (unsigned char)(ascii_part >> 8);

	first_char_pos = (unsigned char)(low_byte >> 2);
	second_char_pos_high_part = (unsigned char)(low_byte & 0x03);
	second_char_pos_low_part = (unsigned char)(high_byte >> 5);
	second_char_pos = (unsigned char)((second_char_pos_high_part << 3) | second_char_pos_low_part);
	third_char_pos = (unsigned char)(high_byte & 0X1F);
	vendor_specific_id = (unsigned short)(pnpid & 0X00000FFF);

	printf("%c%c%c, 0X%X\n", first_char_pos+64, second_char_pos+64, third_char_pos+64, vendor_specific_id);
}

int main( int argc, char *argv[] )
{
	unsigned long status = 0;
	unsigned long val = 0;
	float fVal = 0.0f;


	status = EApiLibInitialize();
	if (EAPI_STATUS_SUCCESS != status)
	{
		printf("EApiLibInitialize() failed, error code: 0x%lX.\n", status);
		return -1;
	}
	else
	{
		printf("EApiLibInitialize() OK.\n");
	}
	
	status = EApiBoardGetValue(EAPI_ID_GET_EAPI_SPEC_VERSION, &val);
	if (EAPI_STATUS_SUCCESS != status)
	{
		printf("Get EAPI Specification Version failed, error code: 0x%lX.\n", status);
		return -1;
	}
	else
	{
		printf("EAPI Specification Version: ");
		ConvertToSpecificationVersionNumberFormat(val);
	}

	status = EApiBoardGetValue(EAPI_ID_BOARD_BOOT_COUNTER_VAL, &val);
	if (EAPI_STATUS_SUCCESS != status)
	{
		printf("Get boot counter failed, error code: 0x%lX.\n", status);
		return -1;
	}
	else
	{
		printf("Boot Counter: %ld\n", val);
	}

	status = EApiBoardGetValue(EAPI_ID_BOARD_RUNNING_TIME_METER_VAL, &val);
	if (EAPI_STATUS_SUCCESS != status)
	{
		printf("Get running time failed, error code: 0x%lX.\n", status);
		return -1;
	}
	else
	{
		printf("Running Time: %ld\n", val);
	}	

	status = EApiBoardGetValue(EAPI_ID_BOARD_PNPID_VAL, &val);
	if (EAPI_STATUS_SUCCESS != status)
	{
		printf("Get Board Vendor PNPID failed, error code: 0x%lX.\n", status);
		return -1;
	}
	else
	{
		printf("Board Vendor PNPID: ");
		UnCompressASCIIPNPID(val);
	}

	status = EApiBoardGetValue(EAPI_ID_BOARD_PLATFORM_REV_VAL, &val);
	if (EAPI_STATUS_SUCCESS != status)
	{
		printf("Get Platform Specification Version failed, error code: 0x%lX.\n", status);
		return -1;
	}
	else
	{
		printf("Platform Specification Version: ");
		ConvertToSpecificationVersionNumberFormat(val);
	}

	status = EApiBoardGetValue(EAPI_ID_BOARD_DRIVER_VERSION_VAL, &val);
	if (EAPI_STATUS_SUCCESS != status)
	{
		printf("Get Driver Specification Version failed, error code: 0x%lX.\n", status);
		return -1;
	}
	else
	{
		printf("Driver Specification Version: ");
		ConvertToGeneralVersionNumberFormat(val);
	}

	status = EApiBoardGetValue(EAPI_ID_BOARD_LIB_VERSION_VAL, &val);
	if (EAPI_STATUS_SUCCESS != status)
	{
		printf("Get Library Specification Version failed, error code: 0x%lX.\n", status);
		return -1;
	}
	else
	{
		printf("Library Specification Version: ");
		ConvertToGeneralVersionNumberFormat(val);
	}

	status = EApiBoardGetValue(EAPI_ID_BOARD_FIRMWARE_VERSION_VAL, &val);
	if (EAPI_STATUS_SUCCESS != status)
	{
		printf("Get Firmware Version failed, error code: 0x%lX.\n", status);
		return -1;
	}
	else
	{
		printf("Firmware Version: ");
		ConvertToGeneralVersionNumberFormat(val);
	}

	val = 0;
	EApiHWMGetCaps(EAPI_ID_HWMON_CPU_TEMP, &val);
	if(1 == val)
	{
		status = EApiBoardGetValue(EAPI_ID_HWMON_CPU_TEMP, &val);
		if (EAPI_STATUS_SUCCESS != status)
		{
			printf("Get CPU Temperature failed, error code: 0x%lX.\n", status);
			return -1;
		}
		else
		{
			printf("CPU Temperature: %ld\n", val);
		}
	}
	
	val = 0;
	EApiHWMGetCaps(EAPI_ID_HWMON_CHIPSET_TEMP, &val);
	if(1 == val)
	{
		status = EApiBoardGetValue(EAPI_ID_HWMON_CHIPSET_TEMP, &val);
		if (EAPI_STATUS_SUCCESS != status)
		{
			printf("Get Chipset Temperature failed, error code: 0x%lX.\n", status);
			return -1;
		}
		else
		{
			printf("Chipset Temperature: %ld\n", val);
		}
	}

	val = 0;
	EApiHWMGetCaps(EAPI_ID_HWMON_SYSTEM_TEMP, &val);
	if(1 == val)
	{
		status = EApiBoardGetValue(EAPI_ID_HWMON_SYSTEM_TEMP, &val);
		if (EAPI_STATUS_SUCCESS != status)
		{
			printf("Get System Temperature failed, error code: 0x%lX.\n", status);
			return -1;
		}
		else
		{
			printf("System Temperature: %ld\n", val);
		}
	}

	val = 0;
	EApiHWMGetCaps(EAPI_ID_HWMON_VOLTAGE_VCORE, &val);
	if(1 == val)
	{
		status = EApiBoardGetValue(EAPI_ID_HWMON_VOLTAGE_VCORE, &val);
		if (EAPI_STATUS_SUCCESS != status)
		{
			printf("Get CPU Core Voltage failed, error code: 0x%lX.\n", status);
			return -1;
		}
		else
		{
			fVal = (float)val / 1000.0f;
			printf("CPU Core Voltage: %.3f\n", fVal);
		}
	}

	val = 0;
	EApiHWMGetCaps(EAPI_ID_HWMON_VOLTAGE_2V5, &val);
	if(1 == val)
	{
		status = EApiBoardGetValue(EAPI_ID_HWMON_VOLTAGE_2V5, &val);
		if (EAPI_STATUS_SUCCESS != status)
		{
			printf("Get 2.5V Voltage failed, error code: 0x%lX.\n", status);
			return -1;
		}
		else
		{
			fVal = (float)val / 1000.0f;
			printf("2.5V Voltage: %.3f\n", fVal);
		}
	}

	val = 0;
	EApiHWMGetCaps(EAPI_ID_HWMON_VOLTAGE_3V3, &val);
	if(1 == val)
	{
		status = EApiBoardGetValue(EAPI_ID_HWMON_VOLTAGE_3V3, &val);
		if (EAPI_STATUS_SUCCESS != status)
		{
			printf("Get 3.3V Voltage failed, error code: 0x%lX.\n", status);
			return -1;
		}
		else
		{
			fVal = (float)val / 1000.0f;
			printf("3.3V Voltage: %.3f\n", fVal);
		}
	}

	val = 0;
	EApiHWMGetCaps(EAPI_ID_HWMON_VOLTAGE_VBAT, &val);
	if(1 == val)
	{
		status = EApiBoardGetValue(EAPI_ID_HWMON_VOLTAGE_VBAT, &val);
		if (EAPI_STATUS_SUCCESS != status)
		{
			printf("Get Battery Voltage failed, error code: 0x%lX.\n", status);
			return -1;
		}
		else
		{
			fVal = (float)val / 1000.0f;
			printf("Battery Voltage: %.3f\n", fVal);
		}
	}

	val = 0;
	EApiHWMGetCaps(EAPI_ID_HWMON_VOLTAGE_5V, &val);
	if(1 == val)
	{
		status = EApiBoardGetValue(EAPI_ID_HWMON_VOLTAGE_5V, &val);
		if (EAPI_STATUS_SUCCESS != status)
		{
			printf("Get 5V Voltage failed, error code: 0x%lX.\n", status);
			return -1;
		}
		else
		{
			fVal = (float)val / 1000.0f;
			printf("5V Voltage: %.3f\n", fVal);
		}
	}

	val = 0;
	EApiHWMGetCaps(EAPI_ID_HWMON_VOLTAGE_5VSB, &val);
	if(1 == val)
	{
		status = EApiBoardGetValue(EAPI_ID_HWMON_VOLTAGE_5VSB, &val);
		if (EAPI_STATUS_SUCCESS != status)
		{
			printf("Get 5V Standby Voltage failed, error code: 0x%lX.\n", status);
			return -1;
		}
		else
		{
			fVal = (float)val / 1000.0f;
			printf("5V Standby Voltage: %.3f\n", fVal);
		}
	}

	val = 0;
	EApiHWMGetCaps(EAPI_ID_HWMON_VOLTAGE_12V, &val);
	if(1 == val)
	{
		status = EApiBoardGetValue(EAPI_ID_HWMON_VOLTAGE_12V, &val);
		if (EAPI_STATUS_SUCCESS != status)
		{
			printf("Get 12V Voltage failed, error code: 0x%lX.\n", status);
			return -1;
		}
		else
		{
			fVal = (float)val / 1000.0f;
			printf("12V Voltage: %.3f\n", fVal);
		}
	}

	val = 0;
	EApiHWMGetCaps(EAPI_ID_HWMON_FAN_CPU, &val);
	if(1 == val)
	{
		status = EApiBoardGetValue(EAPI_ID_HWMON_FAN_CPU, &val);
		if (EAPI_STATUS_SUCCESS != status)
		{
			printf("Get CPU Fan failed, error code: 0x%lX.\n", status);
			return -1;
		}
		else
		{
			printf("CPU Fan: %ld\n", val);
		}
	}

	val = 0;
	EApiHWMGetCaps(EAPI_ID_HWMON_FAN_SYSTEM, &val);
	if(1 == val)
	{
		status = EApiBoardGetValue(EAPI_ID_HWMON_FAN_SYSTEM, &val);
		if (EAPI_STATUS_SUCCESS != status)
		{
			printf("Get System Fan failed, error code: 0x%lX.\n", status);
			return -1;
		}
		else
		{
			printf("System Fan: %ld\n", val);
		}
	}

	status = EApiLibUnInitialize();
	if (EAPI_STATUS_SUCCESS != status)
	{
		printf("EApiLibUnInitialize() failed, error code: 0x%lX.\n", status);
		return -1;
	}
	else
	{
		printf("EApiLibUnInitialize() OK.\n");
	}
	
	
	return 0;
}
