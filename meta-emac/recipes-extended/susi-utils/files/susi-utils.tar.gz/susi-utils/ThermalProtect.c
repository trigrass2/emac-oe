#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "define.h"
#include "REL_DEBUG.H"
#include "REL_EC_API.h"

unsigned long get_id_num(int input)
{
	unsigned long id;

	switch(input)
	{
	case 0:
		id = EAPI_ID_THERMAL_PROTECTION_0;
		break;
	case 1:
		id = EAPI_ID_THERMAL_PROTECTION_1;
		break;
	case 2:
		id = EAPI_ID_THERMAL_PROTECTION_2;
		break;
	case 3:
		id = EAPI_ID_THERMAL_PROTECTION_3;
		break;
	default:
		id = EAPI_ID_THERMAL_PROTECTION_0;
		break;
	}

	return id;
}

int get_config()
{
	SUSITHERMALCONFIG Config;
	int input = 0;
	unsigned long id = 0;

	printf("Please input Thermail Protect NO. (0, 1, 2, 3), (0:EAPI_ID_THERMAL_PROTECTION_0, 1:EAPI_ID_THERMAL_PROTECTION_1, 2:EAPI_ID_THERMAL_PROTECTION_2, 3:EAPI_ID_THERMAL_PROTECTION_3):\n");
	if (scanf("%i", &input) <= 0)
		input = 0;
	
	id = get_id_num(input);

	if( EAPI_STATUS_SUCCESS == SusiEC_ThermalProtectionGetConfigStruct( id, &Config) )
	{
		printf("Config.protect_number[%d].dw_source(Thermal Source): 0x%lX\n", input + 1, Config.protect_number[input].dw_source);
		printf("Config.protect_number[%d].dw_event_type(Event Type): 0x%lX\n", input + 1, Config.protect_number[input].dw_event_type);
		printf("Config.protect_number[%d].dw_send_event_temperature(Trigger Temperature): 0x%ld Celsius\n", input + 1, Config.protect_number[input].dw_send_event_temperature);
		printf("Config.protect_number[%d].dw_clear_event_temperature(Stop Temperature): 0x%ld Celsius\n", input + 1, Config.protect_number[input].dw_clear_event_temperature);
	}
	else
	{
		printf("Get configuration failed!!!\n");
	}
	
	return 0;
}

int set_config()
{
	SUSITHERMALCONFIG Config;
	int input;
	unsigned long unit = 0;	
	unsigned long source = 0;
	unsigned long event_type = 0;
	
	printf("Please input Thermail Project NO. (0, 1, 2, 3), (0:EAPI_ID_THERMAL_PROTECTION_0, 1:EAPI_ID_THERMAL_PROTECTION_1, 2:EAPI_ID_THERMAL_PROTECTION_2, 3:EAPI_ID_THERMAL_PROTECTION_3):\n");
	if (scanf("%i", &input) <= 0)
		input = 0;
	
	unit = get_id_num(input);

	printf("Please input Thermail Source Code NO. (0, 1, 2), (0:System(Thermal 1 local), 1:CPU(Thermal 1 remote), 2:Chipset(Thermal 2 local):\n");
	if (scanf("%i", &input) <= 0)
		input = 0;

	source = (unsigned long)input;
	switch(source)
	{
	case 0:
		Config.protect_number[unit].dw_source = THERMAL_PROTECT_SOURCE_THERMAL_1_LOCAL;
		break;
	case 1:
		Config.protect_number[unit].dw_source = THERMAL_PROTECT_SOURCE_THERMAL_1_REMOTE;
		break;
	case 2:
		Config.protect_number[unit].dw_source = THERMAL_PROTECT_SOURCE_THERMAL_2_LOCAL;
		break;
	default:
		break;
	}

	printf("Please input Thermail Protect Event Type. (0, 1, 2), (0:Shutdown, 1:Throttle, 2:Power Off:\n");
	if (scanf("%i", &input) <= 0)
		input = 0;

	event_type = (unsigned long)input;
	switch(event_type)
	{
	case 0:
		Config.protect_number[unit].dw_event_type = THERMAL_PROTECT_EVENT_TYPE_SHUTDOWN;
		break;
	case 1:
		Config.protect_number[unit].dw_event_type = THERMAL_PROTECT_EVENT_TYPE_THROTTLE;
		break;
	case 2:
		Config.protect_number[unit].dw_event_type = THERMAL_PROTECT_EVENT_TYPE_POWER_OFF;
		break;
	default:
		break;
	}
	
	printf("Please input send event temperature(Trigger) value: (0 ~ 120)\n");
	if (scanf("%i", &input) <= 0)
		input = 0;
	Config.protect_number[unit].dw_send_event_temperature = (unsigned int)input;

	printf("Please input clear event temperature temperature(Stop) value: (stop ~ 120)\n");
	if (scanf("%i", &input) <= 0)
		input = 0;
	Config.protect_number[unit].dw_clear_event_temperature = (unsigned int)input;
	
	if( EAPI_STATUS_SUCCESS == SusiEC_ThermalProtectionSetConfigStruct(unit, &Config) )
	{	
		printf("Set configuration OK.\n");
	}
	else
	{
		printf("Set configuration failed!!!\n");
	}
	
	return 0;
}


void show_menu(void)
{
	printf("\n");
	printf("0) Terminate this program\n");
	printf("1) Check Thermail Protection configuration\n");	
	printf("2) Get Thermail Protection configuration\n");
	printf("3) Set Thermail Protection configuration\n");
	printf("Enter your choice: \n");
}

int main( int argc, char *argv[] )
{
	int done, op;
	int result = 0;
	unsigned long status = 0;
	unsigned long val = 0;

	status = EApiLibInitialize();
	if (EAPI_STATUS_SUCCESS != status)
	{
		printf("EApiLibInitialize() failed, error code: 0x%lX.\n", status);
		return -1;
	}
	else
	{
		printf("EApiLibInitialize() OK.\n");
	}

	done = 0;
	
	while (!done)
	{
		show_menu();
		
		if (scanf("%i", &op) <= 0)
			op = -1;
		
		switch (op)
		{
		case 0:
			done = 1;
			continue;		
		case 1:
			val = 0;
			EApiHWMGetCaps(EAPI_ID_HWMON_CPU_TEMP, &val);
			if(1 == val)
			{
				printf("CPU(Thermal 1 remote) exist.\n");
			}else
			{
				printf("CPU(Thermal 1 remote) not exist.\n");
			}
			
			val = 0;
			EApiHWMGetCaps(EAPI_ID_HWMON_SYSTEM_TEMP, &val);
			if(1 == val)
			{
				printf("System(Thermal 1 local) exist.\n");
			}else
			{
				printf("System(Thermal 1 local) not exist.\n");
			}

			val = 0;
			EApiHWMGetCaps(EAPI_ID_HWMON_CHIPSET_TEMP, &val);
			if(1 == val)
			{
				printf("Chipset(Thermal 2 local) exist.\n");
			}else
			{
				printf("Chipset(Thermal 2 local) not exist.\n");
			}
			
			break;		
		case 2:
			result = get_config();
			break;
		case 3:
			result = set_config();
			break;
		default:
			printf("\nUnknown choice!\n");
			
		} /*switch (op)*/
		
		if(done != 1 && result < 0) 
		{
			status = EApiLibUnInitialize();
			if (EAPI_STATUS_SUCCESS != status)
			{
				printf("EApiLibUnInitialize() failed, error code: 0x%lX.\n", status);
				return -1;
			}
			else
			{
				printf("EApiLibUnInitialize() OK.\n");
			}
			
			return -1;
		}
		
	} /*while (!done)*/
	
	status = EApiLibUnInitialize();
	if (EAPI_STATUS_SUCCESS != status)
	{
		printf("EApiLibUnInitialize() failed, error code: 0x%lX.\n", status);
		return -1;
	}
	else
	{
		printf("EApiLibUnInitialize() OK.\n");
	}
	
	return 0;
}