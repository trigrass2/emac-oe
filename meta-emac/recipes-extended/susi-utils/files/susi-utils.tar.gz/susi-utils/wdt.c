#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "define.h"
#include "REL_DEBUG.H"
#include "REL_EC_API.h"


void call_back()
{
	printf("CallBack function called.\r\n");

}

void show_menu(void)
{
	printf("\n");
	printf("0) Terminate this program\n");
	printf("1) Set Event Type\n");
	printf("2) Start WDT\n");
	printf("3) Trigger WDT\n");
	printf("4) Stop WDT\n");
	printf("Enter your choice: \n");
}

int main( int argc, char *argv[] )
{
	int done, op, input;
	unsigned long status = 0;
	unsigned long delay = 0;
	unsigned long type = 0;
	unsigned long eventTimeout = 0;
	unsigned long resetTimeout = 0;


	status = EApiLibInitialize();
	if (EAPI_STATUS_SUCCESS != status)
	{
		printf("EApiLibInitialize() failed, error code: 0x%lX.\n", status);
		return -1;
	}
	else
	{
		printf("EApiLibInitialize() OK.\n");
	}

	status = EApiWDogGetCap(&delay, &eventTimeout, &resetTimeout);
	if (EAPI_STATUS_SUCCESS != status)
	{
		printf("EApiWDogGetCap() failed, error code: 0x%lX.\n", status);
		return -1;
	}
	else
	{
		printf("WDT maximum Delay time value: %ld\n", delay);
		printf("WDT maximum Event Timeout time value: %ld\n", eventTimeout);
		printf("WDT maximum Reset Timeout time value: %ld\n", resetTimeout);
	}

	EApiWDogSetEventType(SUSI_WDOG_EVENT_IRQ);
	SetCallback(call_back);	

	done = 0;
	while (! done) {
		show_menu();
		if (scanf("%i", &op) <= 0)
			op = -1;
		
		switch (op) {
		case 0:
			done = 1;
			continue;

		case 1:
			//Modify Ryan.xin 20120223
			printf("Please input event Type: 1:INT/IRQ, 2:SCI/SMI(Warm reset), 3:Cold reset:\n");
			if (scanf("%i", &input) <= 0)
				input = 1;

			switch(input)
			{
			case 1:
				type = SUSI_WDOG_EVENT_IRQ;
				break;
			case 2:
				type = SUSI_WDOG_EVENT_SCI;
				break;
			case 3:
				type = SUSI_WDOG_EVENT_BTN;
				break;
			default:
				type = SUSI_WDOG_EVENT_IRQ;
				break;
			}				
		
			status = EApiWDogSetEventType(type);
			if (EAPI_STATUS_SUCCESS != status)
			{
				printf("Start WDT event type failed, error code: 0x%lX.\n", status);
				status = -1;
				done = 1;
				continue;
			}
			else
			{
				printf("Start WDT event type OK.\n");
			}
			break;

		case 2:
			printf("Please input Delay time:\n");
			if (scanf("%i", &input) <= 0)
				input = 3000;
			delay = input;

			printf("Please input Event Timeout time:\n");
			if (scanf("%i", &input) <= 0)
				input = 3000;
			eventTimeout = input;

			printf("Please input Reset Timeout time:\n");
			if (scanf("%i", &input) <= 0)
				input = 3000;
			resetTimeout = input;			
		
			status = EApiWDogStart(delay, eventTimeout, resetTimeout);
			if (EAPI_STATUS_SUCCESS != status)
			{
				printf("Start WDT failed, error code: 0x%lX.\n", status);
				status = -1;
				done = 1;
				continue;
			}
			else
			{
				printf("Start WDT OK. (Delay: %ld, Event: %ld, Reset: %ld).\n", delay, eventTimeout, resetTimeout);
			}
			break;

		case 3:			
			status = EApiWDogTrigger();
			if (EAPI_STATUS_SUCCESS != status)
			{
				printf("Trigger WDT failed, error code: 0x%lX.\n", status);
				status = -1;
				done = 1;
				continue;
			}
			else
			{
				printf("Trigger WDT OK.\n");
			}			
			break;

		case 4:
			status = EApiWDogStop();
			if (EAPI_STATUS_SUCCESS != status)
			{
				printf("Stop WDT failed, error code: 0x%lX.\n", status);
				status = -1;
				done = 1;
				continue;
			}
			else
			{
				printf("Stop WDT OK.\n");
			}			
			break;
	
		default:
			printf("\nUnknown choice!\n\n");
			continue;
		}

		if (EAPI_STATUS_SUCCESS != status) 
		{
			status = EApiLibUnInitialize();
			if (EAPI_STATUS_SUCCESS != status)
			{
				printf("EApiLibUnInitialize() failed, error code: 0x%lX.\n", status);
				return -1;
			}
			else
			{
				printf("EApiLibUnInitialize() OK.\r\n");
			}	return -1;
		}
	}	

	status = EApiLibUnInitialize();
	if (EAPI_STATUS_SUCCESS != status)
	{
		printf("EApiLibUnInitialize() failed, error code: 0x%lX.\n", status);
		return -1;
	}
	else
	{
		printf("EApiLibUnInitialize() OK.\r\n");
	}	
	
	return 0;
}
