#ifndef _DEFINE_H_
#define _DEFINE_H_

/*
typedef char				int8_t;
typedef short				int16_t;
typedef int					int32_t;
typedef unsigned char		uint8_t;
typedef unsigned short		uint16_t;
typedef unsigned int		uint32_t;
typedef __int64				int64_t;
typedef unsigned __int64	uint64_t;*/

#ifndef EAPI_UINT32_C
#  define EAPI_UINT8_C(x)  ((uint8_t)(x))
#  define EAPI_UINT16_C(x) ((unsigned short)(x))
#  define EAPI_UINT32_C(x) ((unsigned int)(x))
#endif

///////////////////////////////////////////////////////////////////////////////
// internal define
//#define DEBUG_LEVEL	0xc0000001
//#define DEBUG_LEVEL	0xC0001FFF
//#define DEBUG_LEVEL	0xC0001000
#define DEBUG_LEVEL	0x00000000

#define SUSIEC_CORE_			(1 << 0)
#define SUSIEC_GPIO_			(1 << 1)
#define SUSIEC_HWMONITOR_		(1 << 2)
#define SUSIEC_I2C_SMB_			(1 << 3)
#define SUSIEC_INIT_			(1 << 4)
#define SUSIEC_IF_				(1 << 5)
#define SUSIEC_LIB_				(1 << 6)
#define SUSIEC_SB_SMB_			(1 << 7)
#define SUSIEC_SMART_BATTERY_	(1 << 8)
#define SUSIEC_SMART_FAN_		(1 << 9)
#define SUSIEC_STORAGE_			(1 << 10)
#define SUSIEC_THERAML_ZONE_	(1 << 11)
#define SUSIEC_VGA_				(1 << 12)
#define SUSIEC_WATCH_DOG_		(1 << 13)

#define SUSIEC_CORE				(1 << 16)
#define SUSIEC_GPIO				(1 << 17)
#define SUSIEC_HWMONITOR		(1 << 18)
#define SUSIEC_I2C_SMB			(1 << 19)
#define SUSIEC_INIT				(1 << 20)
#define SUSIEC_IF				(1 << 21)
#define SUSIEC_LIB				(1 << 22)
#define SUSIEC_SB_SMB			(1 << 23)
#define SUSIEC_SMART_BATTERY	(1 << 24)
#define SUSIEC_SMART_FAN		(1 << 25)
#define SUSIEC_STORAGE			(1 << 26)
#define SUSIEC_THERAML_ZONE		(1 << 27)
#define SUSIEC_VGA				(1 << 28)
#define SUSIEC_WATCH_DOG		(1 << 29)
#define SUSIEC_ERROR			(1 << 30)

#define LIBNAME	    "Lib: "
/*odprintf(LIBNAME);\*/
#define Dprintf(LEVEL, STRING) \
	    if ((g_ex_debug_level & SUSIEC_##LEVEL)) \
        {\
			odprintf(STRING);\
        }

#define PCI_MAX_BRIDGE_NUMBER 0x100
#ifndef PCI_MAX_DEVICES
#define PCI_MAX_DEVICES       0x20
#endif
#ifndef PCI_MAX_FUNCTION
#define PCI_MAX_FUNCTION      0x08
#endif

#define READ_BYTE		0x01
#define READ_WORD		0x02
#define READ_DWORD		0x03
#define WRITE_BYTE		0x04
#define WRITE_WORD		0x05
#define WRITE_DWORD		0x06
#define READ_BLOCK		0x07
#define WRITE_BLOCK		0x08
#define CLEAR_BLOCK     0x09

#define BACKLIGHT_MODULATION_FREQUENCY	0xC8254 // 31:16, 15:0->Reserved
#define BACKLIGHT_DUTY_CYCLE			0x48254 // 31:16->Reserved, 15:0

#define DISABLE			0x00
#define ENABLE			0x01

#define UNIT_TYPE				0x01
#define SMALL_BLOCK_TYPE		0x02
#define BLOCK_TYPE				0x03
#define UNIT_TYPE_EX			0x04
#define SMALL_BLOCK_TYPE_EX		0x05
#define BLOCK_TYPE_EX			0x06
#define COMMAND_ONLY_TYPE		0x07
#define BLOCK_TYPE_A			0x08

// external define
#define READ_BYTE		0x01
#define READ_WORD		0x02
#define READ_DWORD		0x03
#define WRITE_BYTE		0x04
#define WRITE_WORD		0x05
#define WRITE_DWORD		0x06
#define READ_BLOCK		0x07
#define WRITE_BLOCK		0x08
#define CLEAR_BLOCK     0x09

#define LOAD_DRV_FROM_SYSTEM_DIR 1
#define DYNAMIC_LOAD_DRV 0

#define EC_VOLTAGE_MAX 14
#define EAPI_KELVINS_OFFSET 2731
#define EC_ADC_VOLTAGE_RESOLUTION_MAX 0x03FF
#define EC_ADC_VOLTAGE_VALUE_MAX 3000

#define EC_PORT_CMD  0x29A
#define EC_PORT_DATA 0x299

#define EC_MAILBOX_PORT_CMD  0x29E
#define EC_MAILBOX_PORT_DATA 0x29F

#define CMD_AUTHENTICATION	0x30

#define MAX_ITEM_NUM 32
#define MAX_DEVICE_ID_NUM 0xFF

#define EC_TABLE_ITEM_UNUSED 0xFF
#define EC_END_OF_TABLE 0xFE
#define EC_TABLE_ITEM_ERROR 0xFF

#define BACKLIGHT_ON_OFF_BIT_POS 0x7

///////////////////////////////////////////////////////////////////////////////
// Classify Device ID Type for Mailbox
#define TYPE_OEMGPIO	0x00
#define TYPE_GPIO		0x01
#define TYPE_PWM		0x02
#define TYPE_SMBUS		0x03
#define TYPE_ADC		0x04
#define TYPE_IRQ		0x05
#define TYPE_TACHO		0x06
#define TYPE_DAC		0x07
#define TYPE_UNKNOW		0x08

///////////////////////////////////////////////////////////////////////////////
// EC Command Table
//


//-----------------------------------------------------------------------------
// GPIO
//-----------------------------------------------------------------------------
#define EC_CMD_GPIO_INDEX							0x10 // Write Pin number into index
#define EC_CMD_GPIO_READ							0x11 // According index, get GPIO pin status
#define EC_CMD_GPIO_WRITE							0x12 // According index, change GPIO pin status
#define EC_CMD_GPIO_GET_DIRECTION					0x1D // According index, get GPIO input/output type
#define EC_CMD_GPIO_SET_DIRECTION					0x1E // According index, change GPIO input/output type

//-----------------------------------------------------------------------------
// DA AD
//-----------------------------------------------------------------------------
#define EC_CMD_DAC_INDEX							0x13 // Write DA port number into index     
#define EC_CMD_DAC_WRITE							0x14 // Write DA value to DA port
#define EC_CMD_ADC_INDEX							0x15 // Write AD port number into index
#define EC_CMD_ADC_READ_LSB							0x16 // Read AD LSB value from AD port
#define EC_CMD_ADC_READ_MSB							0x1F // Read AD MSB value from AD port

//-----------------------------------------------------------------------------
// PWM
//-----------------------------------------------------------------------------
#define EC_CMD_PWM_INDEX							0x17 // Write PWM number into index
#define EC_CMD_PWM_READ								0x18 // According index, get PWM data
#define EC_CMD_PWM_WRITE							0x19 // According index, set PWM data 
#define EC_CMD_PWM_SET_FREQ							0x1A // Set pwm frequency
#define EC_CMD_PWM_SET_POLARITY						0x1B // Set pwm polarity

// 
#define EC_CMD_HWCTRLTABLE_INDEX					0x20 // Write item number into index, 0-31
#define EC_CMD_HWCTRLTABLE_GET_PIN_NUM				0x21 // Get HW pin number, Dynamic, used by software
#define EC_CMD_HWCTRLTABLE_GET_DEVICE_ID			0x22 // Get device ID, Use for scanning
#define EC_CMD_HWCTRLTABLE_GET_PIN_ACTIVE_POLARITY	0x23 // Get pin active polarity, 0x00 low active,
                                                         //                          0x01 high active,                                                       //                          0x02 no defined
//-----------------------------------------------------------------------------
// Watch Dog
//-----------------------------------------------------------------------------
#define EC_CMD_WDOG_START							0x28 // Start watchdog       
#define EC_CMD_WDOG_STOP							0x29 // Stop watchdog
#define EC_CMD_WDOT_RESET							0x2A // Reset watchdog
#define EC_CMD_WDOG_BOOT_TIME						0x2B // Stop boot time watchdog

//
#define EC_CMD_OEM_EEPROM_STEP_POWER_ON_COUNTER		0x2F // Step power on counter

//
#define EC_CMD_SECURITY_CHECK						0x30 // Return Ebrain code 0x95 for AP to check

//
#define EC_CMD_STOP_RTC								0x31 // Stop RTC

//-----------------------------------------------------------------------------
// SCI
//-----------------------------------------------------------------------------
#define EC_CMD_ENABLE_SCI_DISABLE_SMI				0x40 // Enable SCI. Disable SMI
#define EC_CMD_DISABLE_SCI_ENABLE_SMI				0x41 // Disable SCI. Enable SMI
#define EC_CMD_DISABLE_SCI_DISABLE_SMI				0x42 // Disable SCI. Disable SMI

//-----------------------------------------------------------------------------
// ACPI RAM
//-----------------------------------------------------------------------------
#define EC_CMD_ACPIRAM_READ							0x80 // Read ACPI ram space
#define EC_CMD_ACPIRAM_WRITE						0x81 // Write ACPI ram space

//-----------------------------------------------------------------------------
// Extend RAM
//-----------------------------------------------------------------------------
#define EC_CMD_READ_EXTEND_RAM						0x86 // Read EC Extend Ram
#define EC_CMD_WRITE_EXTEND_RAM						0x87 // Write EC Extend Ram

//-----------------------------------------------------------------------------
// HW RAM
//-----------------------------------------------------------------------------
#define EC_CMD_HWRAM_READ							0x88 // Read EC HW ram
#define EC_CMD_HWRAM_WRITE							0x89 // Write EC HW ram

//-----------------------------------------------------------------------------
// SMB I2C
//-----------------------------------------------------------------------------
#define EC_CMD_SMB_INDEX							0x8A // Set selector number (smbus channel)
#define EC_CMD_SMB_DEVICE_ADDR						0x8B // Use device id to control Defined SMBUS device
#define EC_CMD_ENABLE_CHANNEL_I2C					0x8C // Enable channel I2C
#define EC_CMD_DISABLE_CHANNEL_I2C					0x8D // Disable channel I2C
#define EC_CMD_SETUP_SMBUS_FREQUENCY				0x8E // Setup smbus frequency

//-----------------------------------------------------------------------------
// EEPROM
//-----------------------------------------------------------------------------
#define EC_CMD_GET_EEPROM_STATUS					0x90 // Get eeprom status
#define EC_CMD_WRITE_CTRL_REGISTER					0x91 // write control register
#define EC_CMD_GET_PROCESS_RESULT					0x92 // Get process result

#define EC_CMD_SET_INFO_DATA_INDEX					0x93 // Set information data index
#define EC_CMD_READ_INFO_DATA_FROM_BUF				0x94 // Read information data from buffer
#define EC_CMD_WRITE_INFO_DATA_TO_BUF				0x95 // write data to information buffer

#define EC_CMD_SET_OEM_EEPROM_BANK					0x96 // set oem eeprom bank
#define EC_CMD_SET_OEM_EEPROM_INDEX					0x97 // set oem eeprom index
#define EC_CMD_READ_OEM_EEPROM_DATA					0x98 // read oem eeprom data
#define EC_CMD_WRITE_OEM_EEPROM_DATA				0x99 // write oem eeprom data
#define EC_CMD_GET_INFO_DATA_SIZE					0x9A // Get information data size. For example, if return 0x80, 0x00~0x7F is information data size
#define EC_CMD_APPLY_EEPROM_CONFIGURATION_DATA		0x9B // Apply eeprom EC configuration data. If send this command to EC, EC will reget configuration data from eeprom and apply these data to EC control.

//
#define EC_CMD_FLASH_ROM_START						0xDC // Flash Rom start
#define EC_CMD_SIMULATE_KBC_0XFE_COMMAND			0xFE // Simulate KBC 0xFE command
// End EC Command Table
///////////////////////////////////////////////////////////////////////////////

///////////////////////////////////////////////////////////////////////////////
// Device ID Table
//-----------------------------------------------------------------------------
// GPIO
//-----------------------------------------------------------------------------
#define EC_DID_ALTGPIO_0			0x10
#define EC_DID_ALTGPIO_1			(EC_DID_ALTGPIO_0 + 1)
#define EC_DID_ALTGPIO_2			(EC_DID_ALTGPIO_0 + 2)
#define EC_DID_ALTGPIO_3			(EC_DID_ALTGPIO_0 + 3)
#define EC_DID_ALTGPIO_4			(EC_DID_ALTGPIO_0 + 4)
#define EC_DID_ALTGPIO_5			(EC_DID_ALTGPIO_0 + 5)
#define EC_DID_ALTGPIO_6			(EC_DID_ALTGPIO_0 + 6)
#define EC_DID_ALTGPIO_7			(EC_DID_ALTGPIO_0 + 7)

//-----------------------------------------------------------------------------
// Button
//-----------------------------------------------------------------------------
#define EC_DID_BTN_0				0x18
#define EC_DID_BTN_1				(EC_DID_BTN_0 + 1)
#define EC_DID_BTN_2				(EC_DID_BTN_0 + 2)
#define EC_DID_BTN_3				(EC_DID_BTN_0 + 3)
#define EC_DID_BTN_4				(EC_DID_BTN_0 + 4)
#define EC_DID_BTN_5				(EC_DID_BTN_0 + 5)
#define EC_DID_BTN_6				(EC_DID_BTN_0 + 6)
#define EC_DID_BTN_7				(EC_DID_BTN_0 + 7)

//-----------------------------------------------------------------------------
// PWM
//-----------------------------------------------------------------------------
#define EC_DID_PWM_FAN_0_2P			0x20
#define EC_DID_PWM_FAN_0_4P			(EC_DID_PWM_FAN_0_2P + 1)
#define EC_DID_PWM_FAN_1_2P			(EC_DID_PWM_FAN_0_2P + 2)
#define EC_DID_PWM_FAN_1_4P			(EC_DID_PWM_FAN_0_2P + 3)
#define EC_DID_PWM_FAN_2_2P			(EC_DID_PWM_FAN_0_2P + 4)
#define EC_DID_PWM_FAN_2_4P			(EC_DID_PWM_FAN_0_2P + 5)
#define EC_DID_PWM_BRIGHT			(EC_DID_PWM_FAN_0_2P + 6)
#define EC_DID_PWM_BEEP				(EC_DID_PWM_FAN_0_2P + 7)

//-----------------------------------------------------------------------------
// SMBus
//-----------------------------------------------------------------------------
#define EC_DID_SMB_OEM_0			0x28 // EEPROM
#define EC_DID_SMB_OEM_1			(EC_DID_SMB_OEM_0 + 1) // External
#define EC_DID_SMB_OEM_2			(EC_DID_SMB_OEM_0 + 2) // Thermal
#define EC_DID_SMB_EEPROM			(EC_DID_SMB_OEM_0 + 3) // Q7
#define EC_DID_SMB_THERMAL_0		(EC_DID_SMB_OEM_0 + 4)
#define EC_DID_SMB_THERMAL_1		(EC_DID_SMB_OEM_0 + 5)
#define EC_DID_SMB_SECURITY_EEPROM	(EC_DID_SMB_OEM_0 + 6)
//
#define EC_DID_I2C_OEM_1			0x2F

//-----------------------------------------------------------------------------
// Speaker
//-----------------------------------------------------------------------------
#define EC_DID_DAC_SPEAKER			0x30

//
#define EC_DID_EEP_SMB_1K			0x38
#define EC_DID_EEP_OEM				(EC_SMB_EEP_1K + 1)
#define EC_DID_EEP_OEM_1K			(EC_SMB_EEP_1K + 2)

//-----------------------------------------------------------------------------
// LED
//-----------------------------------------------------------------------------
#define EC_DID_LED_POWER			0x40
#define EC_DID_LED_BAT				(EC_DID_LED_POWER + 1)
#define EC_DID_LED_OEM_0			(EC_DID_LED_POWER + 2)
#define EC_DID_LED_OEM_1			(EC_DID_LED_POWER + 3)
#define EC_DID_LED_OEM_2			(EC_DID_LED_POWER + 4)

//-----------------------------------------------------------------------------
// Smart Battery
//-----------------------------------------------------------------------------
#define EC_DID_SMART_BAT1			0x48
#define EC_DID_SMART_BAT2			(EC_DID_SMART_BAT1 + 1)

//-----------------------------------------------------------------------------
// ADC
//-----------------------------------------------------------------------------
#define EC_DID_ADC_CMOSBAT			0x50
#define EC_DID_ADC_CMOSBATx2		(EC_DID_ADC_CMOSBAT + 1)
#define EC_DID_ADC_CMOSBATx10		(EC_DID_ADC_CMOSBAT + 2)
#define EC_DID_ADC_BAT				(EC_DID_ADC_CMOSBAT + 3)
#define EC_DID_ADC_BATx2			(EC_DID_ADC_CMOSBAT + 4)
#define EC_DID_ADC_BATx10			(EC_DID_ADC_CMOSBAT + 5)
#define EC_DID_ADC_5VS0				(EC_DID_ADC_CMOSBAT + 6)
#define EC_DID_ADC_5VS0x2			(EC_DID_ADC_CMOSBAT + 7)
#define EC_DID_ADC_5VS0x10			(EC_DID_ADC_CMOSBAT + 8)
#define EC_DID_ADC_5VS5				(EC_DID_ADC_CMOSBAT + 9)
#define EC_DID_ADC_5VS5x2			(EC_DID_ADC_CMOSBAT + 0xA)
#define EC_DID_ADC_5VS5x10			(EC_DID_ADC_CMOSBAT + 0xB)
#define EC_DID_ADC_33VS0			(EC_DID_ADC_CMOSBAT + 0xC)
#define EC_DID_ADC_33VS0x2			(EC_DID_ADC_CMOSBAT + 0xD)
#define EC_DID_ADC_33VS0x10			(EC_DID_ADC_CMOSBAT + 0xE)
#define EC_DID_ADC_33VS5			(EC_DID_ADC_CMOSBAT + 0xF)
#define EC_DID_ADC_33VS5x2			(EC_DID_ADC_CMOSBAT + 0x10)
#define EC_DID_ADC_33VS5x10			(EC_DID_ADC_CMOSBAT + 0x11)
#define EC_DID_ADC_12VS0			(EC_DID_ADC_CMOSBAT + 0x12)
#define EC_DID_ADC_12VS0x2			(EC_DID_ADC_CMOSBAT + 0x13)
#define EC_DID_ADC_12VS0x10			(EC_DID_ADC_CMOSBAT + 0x14)
#define EC_DID_ADC_VCOREA			(EC_DID_ADC_CMOSBAT + 0x15)
#define EC_DID_ADC_VCOREAx2			(EC_DID_ADC_CMOSBAT + 0x16)
#define EC_DID_ADC_VCOREAx10		(EC_DID_ADC_CMOSBAT + 0x17)
#define EC_DID_ADC_VCOREB			(EC_DID_ADC_CMOSBAT + 0x18)
#define EC_DID_ADC_VCOREBx2			(EC_DID_ADC_CMOSBAT + 0x19)
#define EC_DID_ADC_VCOREBx10		(EC_DID_ADC_CMOSBAT + 0x1A)
#define EC_DID_ADC_DC				(EC_DID_ADC_CMOSBAT + 0x1B)
#define EC_DID_ADC_DCx2				(EC_DID_ADC_CMOSBAT + 0x1C)
#define EC_DID_ADC_DCx10			(EC_DID_ADC_CMOSBAT + 0x1D)
#define EC_DID_ADC_DCSTBY			(EC_DID_ADC_CMOSBAT + 0x1E)
#define EC_DID_ADC_DCSTBYx2			(EC_DID_ADC_CMOSBAT + 0x1F)
#define EC_DID_ADC_DCSTBYx10		(EC_DID_ADC_CMOSBAT + 0x20)
#define EC_DID_ADC_Other			(EC_DID_ADC_CMOSBAT + 0x21)
#define EC_DID_ADC_Otherx2			(EC_DID_ADC_CMOSBAT + 0x22)
#define EC_DID_ADC_Otherx10			(EC_DID_ADC_CMOSBAT + 0x23)
#define EC_DID_WDT_IRQ				0x78
#define EC_DID_WDT_NMI				(EC_DID_WDT_IRQ + 1)

//-----------------------------------------------------------------------------
// TACHO
//-----------------------------------------------------------------------------
#define EC_DID_TACHO_0				0x80
#define EC_DID_TACHO_1				(EC_DID_TACHO_0 + 1)
#define EC_DID_TACHO_2				(EC_DID_TACHO_0 + 2)
// End Device ID Table
///////////////////////////////////////////////////////////////////////////////

///////////////////////////////////////////////////////////////////////////////
// ACPI RAM Address Table
// 0x00-0x1F, Battery 1
// 0x20-0x3F, Battery 2
#define EC_ACPIRAM_ADDR_BRIGHTNESS_LEVEL	0x50
#define EC_ACPIRAM_ADDR_SPEAKER_GAIN_LECVEL	0x51
//
#define EC_ACPIRAM_ARRD_THERMAL_1_REMOTE_TEMPERATURE_OFFSET 0x5E
#define EC_ACPIRAM_ADDR_THERMAL_2_REMOTE_TEMPERATURE_OFFSET (EC_ACPIRAM_ARRD_THERMAL_1_REMOTE_TEMPERATURE_OFFSET+1)
//
#define EC_ACPIRAM_ADDR_THERMAL_1_LOCAL_TEMPERATURE			0x60
#define EC_ACPIRAM_ADDR_THERMAL_1_REMOTE_TEMPERATURE		(EC_ACPIRAM_ADDR_THERMAL_1_LOCAL_TEMPERATURE+1)
#define EC_ACPIRAM_ADDR_THERMAL_1_WARNING_TEMPERATURE		(EC_ACPIRAM_ADDR_THERMAL_1_LOCAL_TEMPERATURE+2) // shutdown temperature, monitor 61
#define EC_ACPIRAM_ADDR_THERMAL_2_LOCAL_TEMPERATURE			(EC_ACPIRAM_ADDR_THERMAL_1_LOCAL_TEMPERATURE+3)
#define EC_ACPIRAM_ADDR_THERMAL_2_REMOTE_TEMPERATURE		(EC_ACPIRAM_ADDR_THERMAL_1_LOCAL_TEMPERATURE+4)
#define EC_ACPIRAM_ADDR_THERMAL_2_WARNING_TEMPERATURE		(EC_ACPIRAM_ADDR_THERMAL_1_LOCAL_TEMPERATURE+5) // shutdown temperature, monitor 63
// 0x66-0x67, Light sensor Dat 0
// 0x68-0x69, Light sensor Dat 1
//
#define EC_ACPIRAM_ADDR_FAN_SPEED		0x70
#define EC_ACPIRAM_ADDR_FAN0_SPEED_MSB	(EC_ACPIRAM_ADDR_FAN_SPEED + 0x00)
#define EC_ACPIRAM_ADDR_FAN0_SPEED_LSB	(EC_ACPIRAM_ADDR_FAN_SPEED + 0x01)
#define EC_ACPIRAM_ADDR_FAN1_SPEED_MSB  (EC_ACPIRAM_ADDR_FAN_SPEED + 0x02)
#define EC_ACPIRAM_ADDR_FAN1_SPEED_LSB	(EC_ACPIRAM_ADDR_FAN_SPEED + 0x03)
#define EC_ACPIRAM_ADDR_FAN2_SPEED_MSB	(EC_ACPIRAM_ADDR_FAN_SPEED + 0x04)
#define EC_ACPIRAM_ADDR_FAN2_SPEED_LSB	(EC_ACPIRAM_ADDR_FAN_SPEED + 0x05)
//
#define EC_ACPIRAM_ADDR_FAN_SPEED_HIGH_LOW_LIMIT	0x76
#define EC_ACPIRAM_ADDR_FAN0_SPEED_LOW_LIMIT_MSB	(EC_ACPIRAM_ADDR_FAN_SPEED_HIGH_LOW_LIMIT + 0x00)
#define EC_ACPIRAM_ADDR_FAN0_SPEED_LOW_LIMIT_LSB	(EC_ACPIRAM_ADDR_FAN_SPEED_HIGH_LOW_LIMIT + 0x01)
#define EC_ACPIRAM_ADDR_FAN0_SPEED_HIGH_LIMIT_MSB	(EC_ACPIRAM_ADDR_FAN_SPEED_HIGH_LOW_LIMIT + 0x02)
#define EC_ACPIRAM_ADDR_FAN0_SPEED_HIGH_LIMIT_LSB	(EC_ACPIRAM_ADDR_FAN_SPEED_HIGH_LOW_LIMIT + 0x03)
#define EC_ACPIRAM_ADDR_FAN1_SPEED_LOW_LIMIT_MSB	(EC_ACPIRAM_ADDR_FAN_SPEED_HIGH_LOW_LIMIT + 0x04)
#define EC_ACPIRAM_ADDR_FAN1_SPEED_LOW_LIMIT_LSB	(EC_ACPIRAM_ADDR_FAN_SPEED_HIGH_LOW_LIMIT + 0x05)
#define EC_ACPIRAM_ADDR_FAN1_SPEED_HIGH_LIMIT_MSB	(EC_ACPIRAM_ADDR_FAN_SPEED_HIGH_LOW_LIMIT + 0x06)
#define EC_ACPIRAM_ADDR_FAN1_SPEED_HIGH_LIMIT_LSB	(EC_ACPIRAM_ADDR_FAN_SPEED_HIGH_LOW_LIMIT + 0x07)
#define EC_ACPIRAM_ADDR_FAN2_SPEED_LOW_LIMIT_MSB	(EC_ACPIRAM_ADDR_FAN_SPEED_HIGH_LOW_LIMIT + 0x08)
#define EC_ACPIRAM_ADDR_FAN2_SPEED_LOW_LIMIT_LSB	(EC_ACPIRAM_ADDR_FAN_SPEED_HIGH_LOW_LIMIT + 0x09)
#define EC_ACPIRAM_ADDR_FAN2_SPEED_HIGH_LIMIT_MSB	(EC_ACPIRAM_ADDR_FAN_SPEED_HIGH_LOW_LIMIT + 0x0A)
#define EC_ACPIRAM_ADDR_FAN2_SPEED_HIGH_LIMIT_LSB	(EC_ACPIRAM_ADDR_FAN_SPEED_HIGH_LOW_LIMIT + 0x0B)
//
#define EC_ACPIRAM_ADDR_DEVICE_STATUS	0x90
#define EC_ACPIRAM_ADDR_DEVICE_STATUS_2 (EC_ACPIRAM_ADDR_DEVICE_STATUS+1)
#define EC_ACPIRAM_ADDR_SYSTEM_FLAG		(EC_ACPIRAM_ADDR_DEVICE_STATUS+2)
//
#define EC_ACPIRAM_ADDR_THERMAL_EVENT_STATUS 0x98

//0xC3-0xD7, ADC limit ram.
#define EC_ACPIRAM_ADDR_ADC_BASE_ADDR	0xC3
#define EC_ACPIRAM_ADDR_ADC_HW_PIN(N) (EC_ACPIRAM_ADDR_ADC_BASE_ADDR + (5 * N)) // N:0-3
#define EC_ACPIRAM_ADDR_ADC_LO_LIMIT_HIBYTE(N) (EC_ACPIRAM_ADDR_ADC_BASE_ADDR + (5 * N) + 1)
#define EC_ACPIRAM_ADDR_ADC_LO_LIMIT_LOBYTE(N) (EC_ACPIRAM_ADDR_ADC_BASE_ADDR + (5 * N) + 2)
#define EC_ACPIRAM_ADDR_ADC_HI_LIMIT_HIBYTE(N) (EC_ACPIRAM_ADDR_ADC_BASE_ADDR + (5 * N) + 3)
#define EC_ACPIRAM_ADDR_ADC_HI_LIMIT_LOBYTE(N) (EC_ACPIRAM_ADDR_ADC_BASE_ADDR + (5 * N) + 4)

//0xD8-0xEF, Oem alt gpio contrl table. total 8 pins. Each pin occupies 3 bytes.
#define EC_ACPIRAM_ADDR_ALT_GPIO_BASE_ADDR	0xD8
#define EC_ACPIRAM_ADDR_ADC_HW_PIN(N) (EC_ACPIRAM_ADDR_ADC_BASE_ADDR + (5 * N)) // N:0-3
#define EC_ACPIRAM_ADDR_ADC_LO_LIMIT_HIBYTE(N) (EC_ACPIRAM_ADDR_ADC_BASE_ADDR + (5 * N) + 1)
#define EC_ACPIRAM_ADDR_ADC_LO_LIMIT_LOBYTE(N) (EC_ACPIRAM_ADDR_ADC_BASE_ADDR + (5 * N) + 2)
#define EC_ACPIRAM_ADDR_ADC_HI_LIMIT_HIBYTE(N) (EC_ACPIRAM_ADDR_ADC_BASE_ADDR + (5 * N) + 3)
#define EC_ACPIRAM_ADDR_ADC_HI_LIMIT_LOBYTE(N) (EC_ACPIRAM_ADDR_ADC_BASE_ADDR + (5 * N) + 4)

//
#define EC_ACPIRAM_ADDR_KERNEL_CONTROL_FLAG 0xF0
// The version will increase when add a new function or modify it.
#define EC_ACPIRAM_ADDR_KERNEL_MAJOR_VERSION 0xF8
#define EC_ACPIRAM_ADDR_KERNEL_MINOR_VERSION (EC_ACPIRAM_ADDR_KERNEL_MAJOR_VERSION+1)
//
#define EC_ACPIRAM_ADDR_CHIP_VENDOR_CODE	0xFA
#define EC_ACPIRAM_ADDR_CHIP_CODE			(EC_ACPIRAM_ADDR_CHIP_VENDOR_CODE+1)
//
#define EC_ACPIRAM_ADDR_PROJECT_NAME_CODE	0xFC
#define EC_ACPIRAM_ADDR_PROJECT_TYPE_CODE	(EC_ACPIRAM_ADDR_PROJECT_NAME_CODE+1)
// every release will change, even although no any change, just for a specific project
#define EC_ACPIRAM_ADDR_FIRMWARE_MAJOR_VERSION	0xFE
#define EC_ACPIRAM_ADDR_FIRMWARE_MINOR_VERSION	(EC_ACPIRAM_ADDR_FIRMWARE_MAJOR_VERSION+1)
// END ACPI RAM Address Table
///////////////////////////////////////////////////////////////////////////////

///////////////////////////////////////////////////////////////////////////////
// SCI Qevent Table
#define EC_QEVENT_LID_MAKE	0x21
#define EC_QEVENT_LID_BREAK	(EC_QEVENT_LID_MAKE+1)
//
#define EC_QEVENT_SLEEP_BUTTON	0x23
//
#define EC_QEVENT_WATCH_DOG	0x30
//
#define EC_QEVENT_ADAPTOR			0x50
#define EC_QEVENT_BATTERY			(EC_QEVENT_ADAPTOR+1)
#define EC_QEVENT_POWER_BUTTON		(EC_QEVENT_ADAPTOR+2)
#define EC_QEVENT_BATTERY_STATUS	(EC_QEVENT_ADAPTOR+3)
//
#define EC_QEVENT_WARNING_TEMPERATURE	0x60
//
#define EC_QEVENT_FN_AND_ESC	0xF0
#define EC_QEVENT_FN_AND_F1		(EC_QEVENT_FN_AND_ESC+0x01)
#define EC_QEVENT_FN_AND_F2		(EC_QEVENT_FN_AND_ESC+0x02)
#define EC_QEVENT_FN_AND_F3		(EC_QEVENT_FN_AND_ESC+0x03)
#define EC_QEVENT_FN_AND_F4		(EC_QEVENT_FN_AND_ESC+0x04)
#define EC_QEVENT_FN_AND_F5		(EC_QEVENT_FN_AND_ESC+0x05)
#define EC_QEVENT_FN_AND_F6		(EC_QEVENT_FN_AND_ESC+0x06)
#define EC_QEVENT_FN_AND_F7		(EC_QEVENT_FN_AND_ESC+0x07)
#define EC_QEVENT_FN_AND_F8		(EC_QEVENT_FN_AND_ESC+0x08)
#define EC_QEVENT_FN_AND_F9		(EC_QEVENT_FN_AND_ESC+0x09)
#define EC_QEVENT_FN_AND_F10	(EC_QEVENT_FN_AND_ESC+0x0A)
#define EC_QEVENT_FN_AND_F11	(EC_QEVENT_FN_AND_ESC+0x0B)
#define EC_QEVENT_FN_AND_F12	(EC_QEVENT_FN_AND_ESC+0x0C)
#define EC_QEVENT_FN_AND_F13	(EC_QEVENT_FN_AND_ESC+0x0D)
#define EC_QEVENT_FN_AND_F14	(EC_QEVENT_FN_AND_ESC+0x0E)
#define EC_QEVENT_FN_AND_F15	(EC_QEVENT_FN_AND_ESC+0x0F)
// END SCI Qevent Table
///////////////////////////////////////////////////////////////////////////////

///////////////////////////////////////////////////////////////////////////////
// HW RAM Address Table
// (1) SMBus
// 0x00-0x2C, SMBus control ram
#define EC_HWRAM_ADDR_SMB_PROTOCOL  0x00
#define EC_HWRAM_ADDR_SMB_STATUS    0x01
#define EC_HWRAM_ADDR_SMB_ADDRESS   0x02
#define EC_HWRAM_ADDR_SMB_CMD0      0x03
#define EC_HWRAM_ADDR_SMB_DATA(N)   (0x03 + N) // N: 1~32
#define EC_HWRAM_ADDR_SMB_BLOCKCNT  0x24
#define EC_HWRAM_ADDR_SMB_ALARM1    0x25
#define EC_HWRAM_ADDR_SMB_ALM1D0    0x26
#define EC_HWRAM_ADDR_SMB_ALM1D1    0x27
#define EC_HWRAM_ADDR_SMB_ALARM2    0x28
#define EC_HWRAM_ADDR_SMB_ALM2D0    0x29
#define EC_HWRAM_ADDR_SMB_ALM2D1    0x2A
#define EC_HWRAM_ADDR_SMB_SELECTOR  0x2B
#define EC_HWRAM_ADDR_SMB_I2CCTL    0x2C

// 0x37-0x40, Brightness level table. Total 10 levels.
#define EC_HWRAM_ADDR_BRIGHTNESS_LEVEL	(0x37 + N) // N: 0-9

#define EC_HWRAM_ADDR_BRIGHTNESS_TYPE					0x4C
#define EC_HWRAM_ADDR_BRIGHTNESS_PWM_FREQUENCY_HI_BYTE	(EC_HWRAM_ADDR_BRIGHTNESS_TYPE+1)
#define EC_HWRAM_ADDR_BRIGHTNESS_PWM_FREQUENCY_LOW_BYTE	(EC_HWRAM_ADDR_BRIGHTNESS_TYPE+2)
#define EC_HWRAM_ADDR_BRIGHTNESS_ENABLE_ON_DELAY		(EC_HWRAM_ADDR_BRIGHTNESS_TYPE+3)
#define EC_HWRAM_ADDR_BRIGHTNESS_ENABLE_OFF_DELAY		(EC_HWRAM_ADDR_BRIGHTNESS_TYPE+4)

// Speaker
// 0x41-0x4A, Speaker gain level table. Total 10 levels.
#define EC_HWRAM_ADDR_SPEAKER_GAIN_LEVEL(N)	(0x41 + N) // N: 0-9

// (2) FAN
#define EC_HWRAM_ADDR_FAN_0_BASE                     0xD0
#define EC_HWRAM_ADDR_FAN_1_BASE                     0xE0
#define EC_HWRAM_ADDR_FAN_2_BASE                     0xF0 //??
#define EC_HWRAM_ADDR_FAN_CODE(N)                   (0xD0 + 0x10*N)  // (HW Pin number)
#define EC_HWRAM_ADDR_FAN_STATUS(N)                 (0xD1 + 0x10*N)
#define EC_HWRAM_ADDR_FAN_CONTROL(N)                (0xD2 + 0x10*N)
#define EC_HWRAM_ADDR_FAN_TEMP_HI(N)                (0xD3 + 0x10*N)  // Hi temperature limit. When temperature rise to this value, EC turns hi fan.
#define EC_HWRAM_ADDR_FAN_TEMP_LO(N)                (0xD4 + 0x10*N)  // (Fan temp limit)Low temperature limit. When temperature rise to this value, EC turns on fan and run lo fan.
#define EC_HWRAM_ADDR_FAN_TEMP_LOSTOP(N)            (0xD5 + 0x10*N)  // Low stop temperature limit. When temperature cool down to this value, EC turns off fan. (Gap)
#define EC_HWRAM_ADDR_FAN_PWM_HI(N)                 (0xD6 + 0x10*N)
#define EC_HWRAM_ADDR_FAN_PWM_LO(N)                 (0xD7 + 0x10*N)
//#define EC_HWRAM_ADDR_FAN_RPM_HI_HIBYTE(N)          (0xD8 + 0x10*N)  // (Speed control, RPM) In hi fan mode, EC use this speed value to control fan.
//#define EC_HWRAM_ADDR_FAN_RPM_HI_LOBYTE(N)          (0xD9 + 0x10*N)
//#define EC_HWRAM_ADDR_FAN_RPM_LO_HIBYTE(N)          (0xDA + 0x10*N)  // (PWM control) In low fan mode, EC use this pwm value to control fan.
//#define EC_HWRAM_ADDR_FAN_RPM_LO_LOBYTE(N)          (0xDB + 0x10*N)
#define EC_HWRAM_ADDR_FAN_HI_RPM_HIBYTE(N)          (0xD8 + 0x10*N)  // (Speed control, RPM) In hi fan mode, EC use this speed value to control fan.
#define EC_HWRAM_ADDR_FAN_HI_RPM_LOBYTE(N)          (0xD9 + 0x10*N)
#define EC_HWRAM_ADDR_FAN_LO_RPM_HIBYTE(N)          (0xDA + 0x10*N)  // (PWM control) In low fan mode, EC use this pwm value to control fan.
#define EC_HWRAM_ADDR_FAN_LO_RPM_LOBYTE(N)          (0xDB + 0x10*N)

#define EC_HWRAM_ADDR_FAN_TIME_DEBOUNCE(N)          (0xDC + 0x10*N)  // Debounce time. (Filter, base:100ms)
#define EC_HWRAM_ADDR_FAN_TEMP_CURRENT(N)           (0xDD + 0x10*N)  // Read only. This temperature controls the fan action.
#define EC_HWRAM_ADDR_FAN_RPM_CONTROL_LOBYTE(N)     (0xDE + 0x10*N)  // (RPM)In fan speed mode, EC will tune fan speed to reach this value, according to current temp
#define EC_HWRAM_ADDR_FAN_RPM_CONTROL_HIBYTE(N)     (0xDF + 0x10*N)  // (RPM)In fan speed mode, EC will tune fan speed to reach this value, according to current temp

// (3) SMBus Thermal Source Control
//#define EC_HWRAM_ADDR_TSC_0_BASE                     0xA0
//#define EC_HWRAM_ADDR_TSC_1_BASE                     0xA6
//#define EC_HWRAM_ADDR_TSC_2_BASE                     0xAC
//#define EC_HWRAM_ADDR_TSC_3_BASE                     0xB2
//#define EC_HWRAM_ADDR_TSC_SMB_CHANNEL(N)            (0xA0 + 0x06*N) //The thermal diode attach on this channel. System can use Device ID SMBOEMX to get HW pin code. This HW pin code is SMB channel code.
//#define EC_HWRAM_ADDR_TSC_SMB_ADDR(N)               (0xA1 + 0x06*N) //Them thermal diode slave address. If this byte is 0xFF, this thermal source item will be skipped.
//#define EC_HWRAM_ADDR_TSC_SMB_CMD(N)                (0xA2 + 0x06*N) //SMB command to get temperature.
//#define EC_HWRAM_ADDR_TSC_TEMP(N)                   (0xA3 + 0x06*N) //EC use above three data to get temperature. The temperature is store in this byte.
//#define EC_HWRAM_ADDR_TSC_STATUS(N)                 (0xA4 + 0x06*N)
//#define EC_HWRAM_ADDR_TSC_FAN_CODE(N)               (0xA5 + 0x06*N)

// (4) Watchdog
//
#define EC_HWRAM_ADDR_WDOG_IRQ_NUMBER 0x52

// 0x53-0x54, Boottime watchdog power off delay limit
#define EC_HWRAM_ADDR_WDOG_BOOTTIME_POWER_OFF_DELAY_LIMIT_HIBYTE	0x53
#define EC_HWRAM_ADDR_WDOG_BOOTTIME_POWER_OFF_DELAY_LIMIT_LOBYTE	0x54

// 0x55-0x56, Boottime watchdog power on delay limit
#define EC_HWRAM_ADDR_WDOG_BOOTTIME_POWER_ON_DELAY_LIMIT_HIBYTE	0x55
#define EC_HWRAM_ADDR_WDOG_BOOTTIME_POWER_ON_DELAY_LIMIT_LOBYTE	0x56

//
#define EC_HWRAM_ADDR_WDOG_EVENT                     0x57
// 0x58-0x59, Watchdog enable delay time
#define EC_HWRAM_ADDR_WDOG_TIME_DLY_HIBYTE           0x58
#define EC_HWRAM_ADDR_WDOG_TIME_DLY_LOBYTE           0x59
// 0x5A-0x5B, Watchdog power button delay time
#define EC_HWRAM_ADDR_WDOG_TIME_BTN_HIBYTE           0x5A
#define EC_HWRAM_ADDR_WDOG_TIME_BTN_LOBYTE           0x5B
// 0x5C-0x5D, Watchdog NMI delay time
#define EC_HWRAM_ADDR_WDOG_TIME_INT_HIBYTE           0x5C
#define EC_HWRAM_ADDR_WDOG_TIME_INT_LOBYTE           0x5D
// 0x5E-0x5F, Watchdog reset delay time
#define EC_HWRAM_ADDR_WDOG_TIME_RST_HIBYTE           0x5E
#define EC_HWRAM_ADDR_WDOG_TIME_RST_LOBYTE           0x5F
// 0x60-0x61, Watchdog pin delay time
#define EC_HWRAM_ADDR_WDOG_TIME_OUT_HIBYTE           0x60
#define EC_HWRAM_ADDR_WDOG_TIME_OUT_LOBYTE           0x61
// 0x62-0x63, Watchdog SCI delay time
#define EC_HWRAM_ADDR_WDOG_TIME_SCI_HIBYTE           0x62
#define EC_HWRAM_ADDR_WDOG_TIME_SCI_LOBYTE           0x63
// 0x64-0x7F ADC convert ram buffer
// (5) ADC(Hardware monitor: voltages)
#define EC_HWRAM_ADDR_ADC_CHANNEL_HIBYTE(N)         (0x64 + 0x2*N)
#define EC_HWRAM_ADDR_ADC_CHANNEL_LOBYTE(N)         (0x65 + 0x2*N)

//
#define EC_HWRAM_ADDR_POWER_STATE			0x80
#define EC_HWRAM_ADDR_POWER_ON_STEP			(EC_HWRAM_ADDR_POWER_STATE+1)
#define EC_HWRAM_ADDR_POWER_ON_DELAY		(EC_HWRAM_ADDR_POWER_STATE+2)
#define EC_HWRAM_ADDR_POWER_OFF_STEP		(EC_HWRAM_ADDR_POWER_STATE+3)
#define EC_HWRAM_ADDR_POWER_OFF_DELAY		(EC_HWRAM_ADDR_POWER_STATE+4)
#define EC_HWRAM_ADDR_POWER_ON_SOURCE		(EC_HWRAM_ADDR_POWER_STATE+5)
#define EC_HWRAM_ADDR_POWER_SHUTDOWN_CAUSE	(EC_HWRAM_ADDR_POWER_STATE+6)

//
#define EC_HWRAM_ADDR_PM2_GPIO_INDEX	0x88
#define EC_HWRAM_ADDR_PM2_DA_INDEX		(EC_HWRAM_ADDR_PM2_GPIO_INDEX+1)
#define EC_HWRAM_ADDR_PM2_INDEX			(EC_HWRAM_ADDR_PM2_GPIO_INDEX+2)
#define EC_HWRAM_ADDR_PM2_PWM_INDEX		(EC_HWRAM_ADDR_PM2_GPIO_INDEX+3)
#define EC_HWRAM_ADDR_PM2_DYNAMIC_TABLE_INDEX (EC_HWRAM_ADDR_PM2_GPIO_INDEX+4)

// THERMAL PROTECTION
#define THERMAL_PROTECT_SOURCE_NO_DEFINE		0x00
#define THERMAL_PROTECT_SOURCE_THERMAL_1_LOCAL	0x01
#define THERMAL_PROTECT_SOURCE_THERMAL_1_REMOTE	0x02 // CPU
#define THERMAL_PROTECT_SOURCE_THERMAL_2_LOCAL	0x03
#define THERAML_PROTECT_SOURCE_THERMAL_2_REMOTE	0x04

#define THERMAL_PROTECT_EVENT_TYPE_SHUTDOWN		0x00
#define THERMAL_PROTECT_EVENT_TYPE_THROTTLE		0x01
#define THERMAL_PROTECT_EVENT_TYPE_POWER_OFF	0x02
#define THERMAL_PROTECT_EVENT_TYPE_NO_EVENT		0x08

#define THERMAL_PROTECT_EVENT_TEMPERATURE_ACPI_ADDRESS_5A	0xDA
#define THERMAL_PROTECT_EVENT_TEMPERATURE_ACPI_ADDRESS_5B	0xDB
#define THERMAL_PROTECT_EVENT_TEMPERATURE_ACPI_ADDRESS_62	0xE2
#define THERMAL_PROTECT_EVENT_TEMPERATURE_ACPI_ADDRESS_65	0xE5


// EC_HWRAM_ADDR_THERMAL_PROTECTION_TABLE 0x8D-0x9C
#define EC_HWRAM_ADDR_THERMAL_PROTECT_BASE_ADDR	0x8D
#define EC_HWRAM_ADDR_THERMAL_PROTECT_SOURCE(N) (EC_HWRAM_ADDR_THERMAL_PROTECT_BASE_ADDR + (4 * N)) // N:0-3
#define EC_HWRAM_ADDR_THERMAL_PROTECT_EVENT_TYPE(N) (EC_HWRAM_ADDR_THERMAL_PROTECT_BASE_ADDR + (4 * N) + 1)
#define EC_HWRAM_ADDR_THERMAL_PROTECT_SEND_EVENT_TEMPERATURE(N) (EC_HWRAM_ADDR_THERMAL_PROTECT_BASE_ADDR + (4 * N) + 2)
#define EC_HWRAM_ADDR_THERMAL_PROTECT_CLEAR_EVENT_TEMPERATURE(N) (EC_HWRAM_ADDR_THERMAL_PROTECT_BASE_ADDR + (4 * N) + 3)

// LED_CONTROL_RAM	0xA0-0xAF
#define EC_HWRAM_ADDR_LED_BASE_ADDR	0xA0
#define EC_HWRAM_ADDR_LED_PIN(N) (EC_HWRAM_ADDR_LED_BASE_ADDR + (4 * N)) // N:0-3
#define EC_HWRAM_ADDR_LED_CONTROL_HIBYTE(N) (EC_HWRAM_ADDR_LED_BASE_ADDR + (4 * N) + 1)
#define EC_HWRAM_ADDR_LED_CONTROL_LOBYTE(N) (EC_HWRAM_ADDR_LED_BASE_ADDR + (4 * N) + 2)
#define EC_HWRAM_ADDR_LED_DEVICE_ID(N) (EC_HWRAM_ADDR_LED_BASE_ADDR + (4 * N) + 3)

// THERMAL_SOURCE_CONTROL_RAM 0xB0-0xC7
#define EC_HWRAM_ADDR_THERMAL_SOURCE_BASE_ADDR 0xB0
#define EC_HWRAM_ADDR_THERMAL_SOURCE_SMB_CHANNEL(N)		(EC_HWRAM_ADDR_THERMAL_SOURCE_BASE_ADDR + (6 * N)) // N:0-3
#define EC_HWRAM_ADDR_THERMAL_SOURCE_SMB_ADDR(N)		(EC_HWRAM_ADDR_THERMAL_SOURCE_BASE_ADDR + (6 * N) + 1)
#define EC_HWRAM_ADDR_THERMAL_SOURCE_SMB_CMD(N)			(EC_HWRAM_ADDR_THERMAL_SOURCE_BASE_ADDR + (6 * N) + 2)
#define EC_HWRAM_ADDR_THERMAL_SOURCE_SMB_STATUS(N)		(EC_HWRAM_ADDR_THERMAL_SOURCE_BASE_ADDR + (6 * N) + 3)
#define EC_HWRAM_ADDR_THERMAL_SOURCE_SMB_FAN_CODE(N)	(EC_HWRAM_ADDR_THERMAL_SOURCE_BASE_ADDR + (6 * N) + 4)
#define EC_HWRAM_ADDR_THERMAL_SOURCE_SMB_TEMPERATURE(N)	(EC_HWRAM_ADDR_THERMAL_SOURCE_BASE_ADDR + (6 * N) + 5)

// THERMAL_SOURCE_LIMIT 0xC8-0xCF
#define EC_HWRAM_ADDR_THERMAL_SOURCE_STATUS 0x9F
#define EC_HWRAM_ADDR_THERMAL_SOURCE_LOW_LIMIT(N)	(0xC8 + (2 * N)) // N:0-3
#define EC_HWRAM_ADDR_THERMAL_SOURCE_HI_LIMIT(N)	(0xC8 + (2 * N) + 1)

//#define EC_HWRAM_ADDR_FAN_CONTROL_RAM 0xD0-0xEF
#define EC_HWRAM_ADDR_FAN_CONTROL_BASE_ADDR					0xD0
#define EC_HWRAM_ADDR_FAN_CONTROL_FAN_CODE(N)				(EC_HWRAM_ADDR_FAN_CONTROL_BASE_ADDR + (16 * N)) // N:0-2
#define EC_HWRAM_ADDR_FAN_CONTROL_STAUS(N)					(EC_HWRAM_ADDR_FAN_CONTROL_BASE_ADDR + (16 * N) + 0x01)
#define EC_HWRAM_ADDR_FAN_CONTROL_CONTROL(N)				(EC_HWRAM_ADDR_FAN_CONTROL_BASE_ADDR + (16 * N) + 0x02)
#define EC_HWRAM_ADDR_FAN_CONTROL_HI_TEMP(N)				(EC_HWRAM_ADDR_FAN_CONTROL_BASE_ADDR + (16 * N) + 0x03)
#define EC_HWRAM_ADDR_FAN_CONTROL_LOW_TEMP(N)				(EC_HWRAM_ADDR_FAN_CONTROL_BASE_ADDR + (16 * N) + 0x04)
#define EC_HWRAM_ADDR_FAN_CONTROL_LOW_STOP_TEMP(N)			(EC_HWRAM_ADDR_FAN_CONTROL_BASE_ADDR + (16 * N) + 0x05)
#define EC_HWRAM_ADDR_FAN_CONTROL_HI_PWM(N)					(EC_HWRAM_ADDR_FAN_CONTROL_BASE_ADDR + (16 * N) + 0x06)
#define EC_HWRAM_ADDR_FAN_CONTROL_LOW_PWM(N)				(EC_HWRAM_ADDR_FAN_CONTROL_BASE_ADDR + (16 * N) + 0x07)
#define EC_HWRAM_ADDR_FAN_CONTROL_HI_SPEED_HIBYTE(N)		(EC_HWRAM_ADDR_FAN_CONTROL_BASE_ADDR + (16 * N) + 0x08)
#define EC_HWRAM_ADDR_FAN_CONTROL_HI_SPEED_LOBYTE(N)		(EC_HWRAM_ADDR_FAN_CONTROL_BASE_ADDR + (16 * N) + 0x09)
#define EC_HWRAM_ADDR_FAN_CONTROL_LOW_SPEED_HIBYTE(N)		(EC_HWRAM_ADDR_FAN_CONTROL_BASE_ADDR + (16 * N) + 0x0A)
#define EC_HWRAM_ADDR_FAN_CONTROL_LOW_SPEED_LOBYTE(N)		(EC_HWRAM_ADDR_FAN_CONTROL_BASE_ADDR + (16 * N) + 0x0B)
#define EC_HWRAM_ADDR_FAN_CONTROL_DEBOUNCE(N)				(EC_HWRAM_ADDR_FAN_CONTROL_BASE_ADDR + (16 * N) + 0x0C)
#define EC_HWRAM_ADDR_FAN_CONTROL_CURRENT_TEMP(N)			(EC_HWRAM_ADDR_FAN_CONTROL_BASE_ADDR + (16 * N) + 0x0D)
#define EC_HWRAM_ADDR_FAN_CONTROL_CTL_FANSPEED_HIBYTE(N)	(EC_HWRAM_ADDR_FAN_CONTROL_BASE_ADDR + (16 * N) + 0x0E)
#define EC_HWRAM_ADDR_FAN_CONTROL_CTL_FANSPEED_LOBYTE(N)	(EC_HWRAM_ADDR_FAN_CONTROL_BASE_ADDR + (16 * N) + 0x0F)

// END HW RAM Address Table
///////////////////////////////////////////////////////////////////////////////

///////////////////////////////////////////////////////////////////////////////
//-----------------------------------------------------------------------------
//Mailbox
//-----------------------------------------------------------------------------
// SMBus/I2C
// I2C
#define EC_CMD_MALLBOX_I2C_WRITEREAD_WITH_READ_BUFFER			0x01
// SMBus
#define EC_CMD_MALLBOX_SMBUS_WRITE_QUICK						0x02
#define EC_CMD_MALLBOX_SMBUS_READ_QUICK							0x03
#define EC_CMD_MALLBOX_SMBUS_SEND_BYTE							0x04
#define EC_CMD_MALLBOX_SMBUS_RECEIVE_BYTE						0x05
#define EC_CMD_MALLBOX_SMBUS_WRITE_BYTE							0x06
#define EC_CMD_MALLBOX_SMBUS_READ_BYTE							0x07
#define EC_CMD_MALLBOX_SMBUS_WRITE_WORD							0x08
#define EC_CMD_MALLBOX_SMBUS_READ_WORD							0x09
#define EC_CMD_MALLBOX_SMBUS_WRITE_BLOCK						0x0A
#define EC_CMD_MALLBOX_SMBUS_READ_BLOCK							0x0B
// I2C
#define EC_CMD_MALLBOX_I2C_READ_WRITE							0x0E
#define EC_CMD_MALLBOX_I2C_WRITE_READ							0x0F
// Watchdog
#define EC_CMD_MALLBOX_POP_WATCHDOG_EVENT_LOG					0x10
// GPIO
#define EC_CMD_MAILBOX_READ_HW_PIN								0x11
#define EC_CMD_MAILBOX_WRITE_HW_PIN								0x12
// STORAGE
#define EC_CMD_MAILBOX_ENABLE_ALL_EC_ACCESS						0x1D
#define EC_CMD_MAILBOX_READ_EC_RAM								0x1E
#define EC_CMD_MAILBOX_WRITE_EC_RAM								0x1F
// OTHERS
#define EC_CMD_MAILBOX_READ_NYNAMIC_TABLE						0x20
#define EC_CMD_MAILBOX_NONVIOLATE_CONFIGURE						0x21
// Watchdog
#define EC_CMD_MAILBOX_WATCHDOG_CONTROL							0x28
// GPIO
#define EC_CMD_MAILBOX_READ_HW_PIN_IN_OUT_ALT					0x30
#define EC_CMD_MAILBOX_WRITE_HW_PIN_IN_OUT_ALT					0x31
// PWM
#define EC_CMD_MAILBOX_SET_PWM_FREQUENCY						0x32
#define EC_CMD_MAILBOX_SET_PWM_POLARITY							0x33
// SMBus
#define EC_CMD_MAILBOX_GET_SMBUS_FREQUENCY						0x34
#define EC_CMD_MAILBOX_SET_SMBUS_FREQUENCY						0x35
// FAN
#define EC_CMD_MAILBOX_READ_FAN_CONTROL							0x40
#define EC_CMD_MAILBOX_WRITE_FAN_CONTROL						0x41
// Thermal Protect
#define EC_CMD_MAILBOX_READ_THERMAL_SOURCE						0x42
#define EC_CMD_MAILBOX_WRITE_THERMAL_SOURCE						0x43
#define EC_CMD_MAILBOX_READ_THERMAL_PROTECT						0x44
#define EC_CMD_MAILBOX_WRITE_THERMAL_PROTECT					0x45
// LED
#define EC_CMD_MAILBOX_READ_LED_CONTROL							0x46
#define EC_CMD_MAILBOX_WRITE_LED_CONTROL						0x47
// SMBus
#define EC_CMD_MALLBOX_SMBUS_WRITE_QUICK_WITH_PEC_CHECK			0x82
#define EC_CMD_MALLBOX_SMBUS_READ_QUICK_WITH_PEC_CHECK			0x83
#define EC_CMD_MALLBOX_SMBUS_SEND_BYTE_WITH_PEC_CHECK			0x84
#define EC_CMD_MALLBOX_SMBUS_RECEIVE_BYTE_WITH_PEC_CHECK		0x85
#define EC_CMD_MALLBOX_SMBUS_WRITE_BYTE_WITH_PEC_CHECK			0x86
#define EC_CMD_MALLBOX_SMBUS_READ_BYTE_WITH_PEC_CHECK			0x87
#define EC_CMD_MALLBOX_SMBUS_WRITE_WORD_WITH_PEC_CHECK			0x88
#define EC_CMD_MALLBOX_SMBUS_READ_WORD_WITH_PEC_CHECK			0x89
#define EC_CMD_MALLBOX_SMBUS_WRITE_BLOCK_WITH_PEC_CHECK			0x8A
#define EC_CMD_MALLBOX_SMBUS_READ_BLOCK_WITH_PEC_CHECK			0x8B
// Storage
#define EC_CMD_MALLBOX_EC_ENTER_RAM_CODE_MODE					0xA0
#define EC_CMD_MALLBOX_EC_LEAVE_RAM_CODE_MODE					0xA1
#define EC_CMD_MALLBOX_READ_SPI_DATA							0xA2
#define EC_CMD_MALLBOX_ERASE_SPI_4K_DATA						0xA3
#define EC_CMD_MALLBOX_WRITE_BUFFER_RAM_DATA_INTO_SPI			0xA4
#define EC_CMD_MALLBOX_WRITE_SPI_STATUS							0xA5
#define EC_CMD_MALLBOX_READ_SPI_STATUS							0xA6
// Others
#define EC_CMD_MALLBOX_PROCESS_PECI								0xB0
// Storage
#define EC_CMD_MALLBOX_CLEAR_256_BYTES_BUFFER					0xC0
#define EC_CMD_MALLBOX_READ_256_BYTES_BUFFER					0xC1
#define EC_CMD_MALLBOX_WRITE_256_BYTES_BUFFER					0xC2
#define EC_CMD_MALLBOX_READ_EEPROM_DATA_INTO_256_BYTES_BUFFER	0xC3
// General Mailbox Command
#define EC_CMD_MAILBOX_GET_FIRMWARE_VERSION_AND_PROJECT_NAME	0xF0
#define EC_CMD_MAILBOX_CLEAR_ALL								0xFF

// Mailbox method
#define IO_CHANNEL				0x00
#define EC_SMBUS_I2C_SLAVE_MODE	0x01
#define ITE_MAILBOX				0x02
#define SHARE_MEMORY			0x03

#define OEM_BANK_DID	0x00

// Mailbox Structure
#define EC_MAILBOX_OFFSET_CMD		0x00
#define EC_MAILBOX_OFFSET_STATUS	(EC_MAILBOX_OFFSET_CMD+1)
#define EC_MAILBOX_OFFSET_PARA		(EC_MAILBOX_OFFSET_CMD+2)
#define EC_MAILBOX_OFFSET_DAT(N)	(EC_MAILBOX_OFFSET_CMD+3+N)

// Mailbox Command Table, for IO Channel using
#define EC_MAILBOX_READ_CMD		0xA0
#define EC_MAILBOX_READ_STATUS	(EC_MAILBOX_READ_CMD+1)
#define EC_MAILBOX_READ_PARA	(EC_MAILBOX_READ_CMD+2)
#define EC_MAILBOX_READ_DAT(N)	(EC_MAILBOX_READ_CMD+3+N)

#define EC_MAILBOX_WRITE_CMD	0x50
#define EC_MAILBOX_WRITE_STATUS	(EC_MAILBOX_WRITE_CMD+1)
#define EC_MAILBOX_WRITE_PARA	(EC_MAILBOX_WRITE_CMD+2)
#define EC_MAILBOX_WRITE_DAT(N)	(EC_MAILBOX_WRITE_CMD+3+N)


// END MailBox Table
///////////////////////////////////////////////////////////////////////////////

///////////////////////////////////////////////////////////////////////////////
// I2C EC Extend RAM Adress
#define EC_I2C_EXTEND_RAM_ADDR_DATA(N)	(N-1) // N: 1~32
#define EC_I2C_EXTEND_RAM_ADDR_WCOUNT	0x20

//
#define GPIO_MAX_NUM	8

#define I2C_MAX_BLOCK_LENGTH 32

//#define I2C_MAX_MAILBOX_WRITE_LENGTH 41

#define SUSI_VGA_BACKLIGHT_MAX 100

// PWM


// EEPROM++
// Command
#define WRITE_ALL_DATA			(0x01 << 0)
#define UPDATE_FAN				(0x01 << 3)
#define UPDATE_TML				(0x01 << 4)
#define UPDATE_GPIO				(0x01 << 5)
#define UPDATE_TBL				(0x01 << 6)
#define UPDATE_BPROT			(0x01 << 7)

#define INIT_OK					(0x01 << 0)
#define INIT_FAIL				(0x01 << 1)
#define WRITE_PROC				(0x01 << 2)
#define WRITE_FAIL				(0x01 << 3)
#define EEP_CRASH				(0x01 << 4)

#define EEPROM_INFO_BLOCK		0x00
#define EEPROM_OEM_BLOCK		0x01

#define EEPROM_MAX_SIZE			0x100

#define EEPROM_OEM_SIZE			0x40 //64bytes

#define EEPROM_SECURE_KEY_SIZE	0x08

#define EC_OPERATE_READ			0x00
#define EC_OPERATE_WRITE		0x01

#define EC_STORAGE_STORAGE_SIZE	256 // user's space is 64bytes
#define EC_STORAGE_BLOCK_LENGTH	64  // 1 block total size

// EEPROM--

// WatchDog
typedef void (SUSI_WDOG_CALLBACK_EVENT_INT) ();

#define EC_WDOG_TIMOUT_BASE		100

#define WDOG_MAX_DELAY_TIME		0xFFFFFFFF
#define WDOG_MAX_EVENT_TIMEOUT	0xFFFFFFFF
#define WDOG_MAX_RESET_TIMEOUT	0xFFFFFFFF
#define WDOG_MIN_TIMEOUT		0x00000000
#define WDOG_TOTAL_STAGE		0x00000003
#define WDOG_TOTAL_EVENT		0x00000005
//
#define EC_WDOG_STATE_START	0x28
#define EC_WDOG_STATE_STOP	0x29
#define EC_WDOG_STATE_RESET	0x2A
//
#define SUSI_WDOG_DELAY_STAGE	0
#define SUSI_WDOG_EVENT_STAGE	1
#define SUSI_WDOG_RESET_STAGE	2
//
#define SUSI_WDOG_EVENT_DLY 0 // IRQ
#define SUSI_WDOG_EVENT_IRQ 1 // IRQ
#define SUSI_WDOG_EVENT_SCI 2 // SMI/SCI
#define SUSI_WDOG_EVENT_BTN 3 // power button
#define SUSI_WDOG_EVENT_RST 4 // system reset
#define SUSI_WDOG_EVENT_NMI 5 // NMI, Reserved

//
#define EC_ERROR	0xFF

// SMBus, smbus channel
#define EC_I2C_CONTROL_CHANNEL_A	0x00000000 // I2C
#define EC_I2C_CONTROL_CHANNEL_B	0x00000001
#define EC_I2C_CONTROL_CHANNEL_C	0x00000002 // SMBus
#define EC_I2C_CONTROL_CHANNEL_D	0x00000003

// SMBus
#define EC_SMB_PROTOCOL_WRITEQUICK            0x02
#define EC_SMB_PROTOCOL_READQUICK             0x03
#define EC_SMB_PROTOCOL_SENDBYTE              0x04
#define EC_SMB_PROTOCOL_RECEIVEBYTE           0x05
#define EC_SMB_PROTOCOL_WRITEBYTE             0x06
#define EC_SMB_PROTOCOL_READBYTE              0x07
#define EC_SMB_PROTOCOL_WRITEWORD             0x08
#define EC_SMB_PROTOCOL_READWORD              0x09
#define EC_SMB_PROTOCOL_WRITEBLOCK            0x0A
#define EC_SMB_PROTOCOL_READBLOCK             0x0B
#define EC_SMB_PROTOCOL_PROCESSCALL           0x0C
#define EC_SMB_PROTOCOL_BLOCK_RW_PROCESSCALL  0x0D
#define EC_I2C_PROTOCOL_BLOCK_READ_WRITE      0x0E
#define EC_I2C_PROTOCOL_BLOCK_WRITE_READ      0x0F


// HWMonitor
#define SUSI_VOLTAGE_CPU        0x00010000		// Volt0, No Use
#define SUSI_VOLTAGE_DC         0x00020000		// Volt1, ADCDC
#define SUSI_VOLTAGE_DC_STANDBY 0x00030000		// Volt2, ADCDCSTBY
#define SUSI_VOLTAGE_BAT_CMOS   0x00040000		// Volt3, ADCCMOSBAT
#define SUSI_VOLTAGE_BAT_POWER  0x00050000		// Volt4, No Use
#define SUSI_VOLTAGE_AC         0x00060000		// Volt5, ADCBAT
#define SUSI_VOLTAGE_OTHER      0x00070000		// Volt6, ADCDCOther
#define SUSI_VOLTAGE_5V_S0      0x00080000		// Volt7, ADC5VS0
#define SUSI_VOLTAGE_5V_S5      0x00090000		// Volt8, ADC5VS5
#define SUSI_VOLTAGE_33V_S0     0x000A0000		// Volt9, ADC33VS0
#define SUSI_VOLTAGE_33V_S5     0x000B0000		// Volt10,ADC33VS5
#define SUSI_VOLTAGE_VCOREA     0x000C0000		// Volt11,ADCVCOREA
#define SUSI_VOLTAGE_VCOREB     0x000D0000		// Volt12,ADCVCOREB
#define SUSI_VOLTAGE_12V_S0     0x000E0000		// Volt13,ADC12VS0

//Fan
#define EC_PWM_MAX 100
#define SUSI_FAN_PWM_MAX 100
#define SUSI_FAN_TEMP_MIN 0
#define SUSI_FAN_TEMP_MAX 125
#define SUSI_FAN_RPM_MAX 0xFFFF

#define SUSI_FAN_MODE_OFF           0x00
#define SUSI_FAN_MODE_FULL          0x01
#define SUSI_FAN_MODE_MANUAL        0x02
#define SUSI_FAN_MODE_AUTO          0x03

#define SUSI_FAN_MODE_AUTO_ZONE0    0x00
#define SUSI_FAN_MODE_AUTO_ZONE1    0x01
#define SUSI_FAN_MODE_AUTO_ZONE2    0x02
#define SUSI_FAN_MODE_AUTO_ZONE3    0x03

#define SUSI_FAN_OPMODE_PWM    0
#define SUSI_FAN_OPMODE_RPM    1

#define EC_FAN_MAX_ZONE 4

#define EC_FAN_STATUS_MASK_INTCTLONLY     0x01  // (EC ROM) Internal Control Only. If 1, EC control the fan. External control is not allowed. If 0, fan can be control by external. 
#define EC_FAN_STATUS_MASK_NTS            0x02  // No Tacho Source. In speed control mode, if tacho source does not be defined, the NoTacho will be set to 1.
#define EC_FAN_STATUS_MASK_NFPT           0x04  // No Fan Pulse Type. In speed control mode, if fan pulse type does not be defined, the NoFantype will be set to 1.
#define EC_FAN_STATUS_MASK_NTSI           0x08  // No Thermal Source Init: 1-no thermal source. 0-thermal source success
#define EC_FAN_STATUS_MASK_I2CF           0x10  // I2C Fail: 1-I2C protocol fail occur. 0-I2C success
#define EC_FAN_STATUS_MASK_CFCT           0xC0  // Current Fan Control Type: EC current control fan mode.
  #define EC_FAN_STATUS_FLAG_CFCT_OFF     0x00
  #define EC_FAN_STATUS_FLAG_CFCT_FULL    0x40
  #define EC_FAN_STATUS_FLAG_CFCT_MANUAL  0x80
  #define EC_FAN_STATUS_FLAG_CFCT_AUTO    0xC0
#define EC_FAN_CONTROL_MASK_FANENABLE     0x01  // (Disable and then enable) If set Enable to 1, this fan starts to work. Else, the fan stop working.
#define EC_FAN_CONTROL_MASK_TC            0x02  // Tacho Control. If set TachoCtl to 1, the fan will enter fan speed mode. Else, the fan will use PWM control. In fan speed mode, ec will get current fan speed with speed source(SSrc) and tune the fan PWM to reach the speed which system set
  #define EC_FAN_CONTROL_FLAG_TC_PWMMODE  0x00
  #define EC_FAN_CONTROL_FLAG_TC_RPMMODE  0x02
#define EC_FAN_CONTROL_MASK_FPT           0x0C  // Fan Pulse Type. There are two types of fan speed feedback. Two pulse/round and 4 pulse/round. EC will use pulse type to calculate real fan speed.
#define EC_FAN_CONTROL_FLAG_FPT_NONE      0x00  // (Do not change)
  #define EC_FAN_CONTROL_FLAG_FPT_2PULSE  0x04  //2 pulse/round type
  #define EC_FAN_CONTROL_FLAG_FPT_4PULSE  0x08  //4 pulse/round type
#define EC_FAN_CONTROL_MASK_SSRC          0x30  // (Do not change) Speed Source. EC has two tacho pin to get fan speed. EC will use this definition to know which tacho feedback is for this fan.
  #define EC_FAN_CONTROL_FLAG_SSRC_NONE   0x00 
  #define EC_FAN_CONTROL_FLAG_SSRC_TACH1  0x10  // TACHO1
  #define EC_FAN_CONTROL_FLAG_SSRC_TACH2  0x20  // TACHO2
#define EC_FAN_CONTROL_MASK_SFTC          0xC0 // (Yes) Set Fan Control Type : System set this flag to change Fan control type. 
  #define EC_FAN_CONTROL_FLAG_SFTC_OFF    0x00 // Fan stop
  #define EC_FAN_CONTROL_FLAG_SFTC_FULL   0x40 // Fan full speed
  #define EC_FAN_CONTROL_FLAG_SFTC_MANUAL 0x80 // Fan manual control
  #define EC_FAN_CONTROL_FLAG_SFTC_AUTO   0xC0 // Smart Fan control.

// SMBus Thermal Source
#define EC_TSC_MAX    4
#define EC_TSC_STATUS_MASK_INTCTLONLY     0x01  // Internal control. Internal control. If 1, EC control the thermal source. External control is not allowed. If 0, thermal source can be control by external
#define EC_TSC_STATUS_MASK_SMLF           0x02  // SMLink fail. If SMLink thermal source is active, this flag will be set when smlink error occurs.
#define EC_TSC_STATUS_MASK_I2CF           0x04  // 1-I2C fail occur. 0 success
#define EC_TSC_STATUS_MASK_TMLT           0xE0  // Thermal type. EC will check this value to update temperature value to ACPI ram space.
  #define EC_TSC_STATUS_FLAG_TMLT_NONE          0x00  // No define
  #define EC_TSC_STATUS_FLAG_TMLT_TML1_LOCAL    0x40  // Thermal 1 local, ACPI address 0x60
  #define EC_TSC_STATUS_FLAG_TMLT_TML1_REMOTE   0x80  // Thermal 1 remote, ACPI address 0x61
  #define EC_TSC_STATUS_FLAG_TMLT_TML2_LOCAL    0xC0  // Thermal 2 local, ACPI address 0x62
  #define EC_TSC_STATUS_FLAG_TMLT_TML2_REMOTE   0x80  // Thermal 1 remote, ACPI address 0x61

///////////////////////////////////////////////////////////////////////////////
// EAPI ID
// Board information
#define EAPI_ID_BOARD_MANUFACTURER_STR			0x00000000 // Board Manufacturer Name String
#define EAPI_ID_BOARD_NAME_STR					0x00000001 // Board Name String
#define EAPI_ID_BOARD_REVISION_STR				0x00000002 // Board Name String
#define EAPI_ID_BOARD_SERIAL_STR				0x00000003 // Board Serial Number String
#define EAPI_ID_BOARD_BIOS_REVISION_STR			0x00000004 // Board Bios Revision String
#define EAPI_ID_BOARD_HW_REVISION_STR			0x00000005 // Board Hardware Revision String
#define EAPI_ID_BOARD_PLATFORM_TYPE_STR			0x00000006 // Platform ID(ETX, COM Express,etc...)

//
#define EAPI_ID_GET_EAPI_SPEC_VERSION			0x00000000 /* EAPI Specification 
                                                            * Revision I.E. The 
                                                            * EAPI Spec Version 
                                                            * Bits 31-24, Revision 
                                                            * 23-16, 15-0 always 0
                                                            * Used to implement 
                                                            * this interface
                                                            */
#define EAPI_ID_BOARD_BOOT_COUNTER_VAL			0x00000001 // Units = Boots
#define EAPI_ID_BOARD_RUNNING_TIME_METER_VAL	0x00000002 // Units = Minutes
#define EAPI_ID_BOARD_PNPID_VAL					0x00000003 /* Encoded PNP ID 
                                                            * Format 
                                                            * (Compressed ASCII)
                                                            */
#define EAPI_ID_BOARD_PLATFORM_REV_VAL			0x00000004 /* Platform Revision 
                                                            * I.E. The PICMG Spec 
                                                            * Version Bits 31-24,
                                                            * Revision 23-16, 
                                                            * 15-0 always 0
                                                            */
#define EAPI_ID_BOARD_DRIVER_VERSION_VAL		0x00010000 // Vendor Specific(Optional)
#define EAPI_ID_BOARD_LIB_VERSION_VAL			0x00010001 // Vendor Specific(Optional)
#define EAPI_ID_BOARD_FIRMWARE_VERSION_VAL		0x00010002

// Temperature
#define EAPI_ID_HWMON_CPU_TEMP					0x00020000 // 1 centigrade
#define EAPI_ID_HWMON_CHIPSET_TEMP				0x00020001 // 1 centigrade
#define EAPI_ID_HWMON_SYSTEM_TEMP				0x00020002 // 1 centigrade

#define EAPI_ID_HWMON_CPU_TEMP1					0x00020010 // 1 centigrade
#define EAPI_ID_HWMON_CHIPSET_TEMP1				0x00020011 // 1 centigrade
#define EAPI_ID_HWMON_SYSTEM_TEMP1				0x00020012 // 1 centigrade

#define EAPI_ID_HWMON_CPU_TEMP2					0x00020020 // 1 centigrade
#define EAPI_ID_HWMON_CHIPSET_TEMP2				0x00020021 // 1 centigrade
#define EAPI_ID_HWMON_SYSTEM_TEMP2				0x00020022 // 1 centigrade

#define EAPI_ID_HWMON_CPU_TEMP3					0x00020030 // 1 centigrade
#define EAPI_ID_HWMON_CHIPSET_TEMP3				0x00020031 // 1 centigrade
#define EAPI_ID_HWMON_SYSTEM_TEMP3				0x00020032 // 1 centigrade

// VOLTAGE
#define EAPI_ID_HWMON_VOLTAGE_VCORE				0x00021004 // Volt.11
#define EAPI_ID_HWMON_VOLTAGE_2V5				0x00021008 // Volt.6
#define EAPI_ID_HWMON_VOLTAGE_3V3				0x0002100C // Volt.9
#define EAPI_ID_HWMON_VOLTAGE_VBAT				0x00021010 // Volt.3
#define EAPI_ID_HWMON_VOLTAGE_5V				0x00021014 // Volt.7
#define EAPI_ID_HWMON_VOLTAGE_5VSB				0x00021018 // Volt.8
#define EAPI_ID_HWMON_VOLTAGE_12V				0x0002101C // Volt.13

// Fan
#define EAPI_ID_HWMON_FAN_CPU					0x00022000 // RPM
#define EAPI_ID_HWMON_FAN_SYSTEM				0x00022001 // RPM
#define EAPI_ID_HWMON_FAN_THIRD					0x00022002 // RPM

// Backlight
#define EAPI_ID_BACKLIGHT_1			0x00000000
#define EAPI_ID_BACKLIGHT_2			0x00000001
#define EAPI_ID_BACKLIGHT_3			0x00000002
#define EAPI_ID_BACKLIGHT_BY_PCH	0x0000000F

#define EAPI_BACKLIGHT_SET_ON			0x00000000
#define EAPI_BACKLIGHT_SET_OFF			0xFFFFFFFF
#define EAPI_BACKLIGHT_SET_DIMEST		0
#define EAPI_BACKLIGHT_SET_BRIGHTEST	100
#define EAPI_BACKLIGHT_SET_FREQUENCYEST	1000000
#define EAPI_BACKLIGHT_SET_LEVELEST		9		

// GPIO ID
#define EAPI_GPIO_ID0	0x00000000
#define EAPI_GPIO_ID1	0x00000001
#define EAPI_GPIO_ID2	0x00000002
#define EAPI_GPIO_ID3	0x00000003
#define EAPI_GPIO_ID4	0x00000004
#define EAPI_GPIO_ID5	0x00000005
#define EAPI_GPIO_ID6	0x00000006
#define EAPI_GPIO_ID7	0x00000007

#define EAPI_ID_GPIO_BANK00	0x00010000
#define EAPI_ID_GPIO_BANK01	0x00010001
#define EAPI_ID_GPIO_BANK02	0x00010002

#define EAPI_GPIO_BITMASK_SELECT   1
#define EAPI_GPIO_BITMASK_NOSELECT 0

#define EAPI_GPIO_LOW     0
#define EAPI_GPIO_HIGH    1

#define EAPI_GPIO_INPUT   1
#define EAPI_GPIO_OUTPUT  0

// I2C Bus
#define EAPI_ID_I2C_EXTERNAL	0x00000000	
#define EAPI_ID_I2C_LVDS_1		0x00000001
#define EAPI_ID_I2C_LVDS_2		0x00000002

#define EAPI_I2C_STD_CMD          (0<<30)
#define EAPI_I2C_EXT_CMD          (2<<30)
#define EAPI_I2C_NO_CMD           (1<<30)    
#define EAPI_I2C_CMD_TYPE_MASK    (3<<30)

// Storage
#define EAPI_ID_STORAGE_STD 0x00000000 // Standard Storage Area >=32Bytes for read/write access

// Thermal Protection
#define EAPI_ID_THERMAL_PROTECTION_0	0x00000000
#define EAPI_ID_THERMAL_PROTECTION_1	0x00000001
#define EAPI_ID_THERMAL_PROTECTION_2	0x00000002
#define EAPI_ID_THERMAL_PROTECTION_3	0x00000003

// EAPI ID
///////////////////////////////////////////////////////////////////////////////

///////////////////////////////////////////////////////////////////////////////
// EAPI macro
#define EAPI_BYTE_SWAP_W(a) \
	    (((a)<<8)&0xFF00)|(((a)>>8)&0x00FF)
#define EAPI_CREATE_PNPID(a, b, c) \
	    EAPI_BYTE_SWAP_W(((( a -'A'+1)&0x1F)<<10)|\
                         ((( b -'A'+1)&0x1F)<< 5)|\
                         ((( c -'A'+1)&0x1F)<< 0) \
                        )
#define EAPI_CREATE_CUST_ID(a, b, c, Id) \
        EAPI_UINT32_C((0xF<<28)|(EAPI_CREATE_PNPID(a, b, c)<<12)|(Id&0xFFF))
#define EAPI_PNPID_PICMG EAPI_CREATE_PNPID('P', 'M', 'G')


#define UINT8_MAX  0xFF
#define  INT8_MAX  0x7F
#define UINT16_MAX 0xFFFF
#define  INT16_MAX 0x7FFF
#define UINT32_MAX 0xFFFFFFFF
#define  INT32_MAX 0x7FFFFFFF
#define UINT64_MAX 0xFFFFFFFFFFFFFFFF
#define  INT64_MAX 0x7FFFFFFFFFFFFFFF

#define EAPI_VER_MASK_VER	0xFF000000
#define EAPI_VER_MASK_REV	0x00FF0000
#define EAPI_VER_MASK_BUILD	0x0000FFFF
#define EAPI_VER_GET_VER(x)		(((x)>>24)&0xFF)
#define EAPI_VER_GET_REV(x)		(((x)>>16)&0xFF)
#define EAPI_VER_GET_BUILD(x)	(((x)>> 0)&0xFFFF)
#define EAPI_VER_CREATE(Version,Revision,Build) (\
                        (((Version )&UINT8_MAX )<<24)|\
                        (((Revision)&UINT8_MAX )<<16)|\
                        (((Build   )&UINT16_MAX)<< 0) \
                    )
/* Embedded API Standard Revision */
#define EAPI_VER      1
#define EAPI_REVISION 0
#define EAPI_VERSION EAPI_VER_CREATE(EAPI_VER, EAPI_REVISION, 0)

// macro
#define M_CheckFlag(CheckWord, flag)	( (CheckWord) & (flag) )
//Voltage
#define ec_voltage_convert(x, y) (y == 0)? (EC_ADC_VOLTAGE_RESOLUTION_MAX * x / EC_ADC_VOLTAGE_VALUE_MAX):(EC_ADC_VOLTAGE_VALUE_MAX * x / EC_ADC_VOLTAGE_RESOLUTION_MAX)
//Temperature
#define EAPI_ENCODE_CELCIUS(Celsius) EAPI_UINT32_C((((Celsius)*10))+EAPI_KELVINS_OFFSET)
#define EAPI_DECODE_CELCIUS(Celsius) ((Celsius)- EAPI_KELVINS_OFFSET)/10
//Fan
#define ec_pwm_convert(x, y) (y == 0)? (EC_PWM_MAX * x / SUSI_FAN_PWM_MAX):(SUSI_FAN_PWM_MAX * x / EC_PWM_MAX)
// Storage
#define EAPI_PMG_ID_STORAGE_SAMPLE       EAPI_CREATE_CUST_ID('P', 'M', 'G', 0)
// I2C
#define EAPI_I2C_ENC_7BIT_ADDR(x)  (((x)&0x07F)<<1)
#define EAPI_I2C_DEC_7BIT_ADDR(x)  (((x)>>1)&0x07F)

#define EAPI_I2C_ENC_10BIT_ADDR(x) (((x)&0xFF)|(((x)&0x0300)<<1)|0xF000)
#define EAPI_I2C_DEC_10BIT_ADDR(x) (((x)&0xFF)|(((x)>>1)&0x300))
#define EAPI_I2C_IS_10BIT_ADDR(x)  (((x)&0xF800)==0xF000)
#define EAPI_I2C_IS_7BIT_ADDR(x)   (!EAPI_I2C_IS_10BIT_ADDR(x))

#define EAPI_I2C_ENC_STD_CMD(x)  (((x)&0xFF)|EAPI_I2C_STD_CMD)
#define EAPI_I2C_ENC_EXT_CMD(x)  (((x)&0xFFFF)|EAPI_I2C_EXT_CMD)
#define EAPI_I2C_IS_EXT_CMD(x)   (((x)&(EAPI_I2C_CMD_TYPE_MASK))==EAPI_I2C_EXT_CMD)
#define EAPI_I2C_IS_STD_CMD(x)   (((x)&(EAPI_I2C_CMD_TYPE_MASK))==EAPI_I2C_STD_CMD)
#define EAPI_I2C_IS_NO_CMD(x)    (((x)&(EAPI_I2C_CMD_TYPE_MASK))==EAPI_I2C_NO_CMD)
// GPIO
#define EAPI_GPIO_BANK_ID(GPIO_NUM)     (0x10000|((GPIO_NUM)>>5))
#define EAPI_GPIO_BANK_MASK(GPIO_NUM)	((1<<((GPIO_NUM)&0x1F))
#define EAPI_GPIO_BANK_TEST_STATE(GPIO_NUM, TState, TValue) \
								 (((TValue>>((GPIO_NUM)&0x1F))&1)==(TState))
#define EAPI_TEST_SUCCESS(x)				(!(x))

#define swapDWORD(dw)	( (((unsigned long)(dw) << 24) & 0xff000000) | \
						  (((unsigned long)(dw) <<  8) & 0x00ff0000) | \
						  (((unsigned long)(dw) >>  8) & 0x0000ff00) | \
						  (((unsigned long)(dw) >> 24) & 0x000000ff) )

#endif