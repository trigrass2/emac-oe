#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "define.h"
#include "REL_DEBUG.H"
#include "REL_EC_API.h"


void show_menu(void)
{
	printf("\n");
	printf("0) Terminate this program\n");
	printf("1) Get Direction\n");
	printf("2) Set Direction\n");
	printf("3) Set Multi Direction\n");
	printf("4) Get Level\n");
	printf("5) Set Level\n");
	printf("6) Set Multi Level\n");
	printf("Enter your choice: \n");
}

int main( int argc, char *argv[] )
{
	int done, op, input;
	unsigned long status = 0;
	unsigned long Inputs = 0;
	unsigned long Outputs = 0;
	unsigned long id = 0;
	unsigned long mask = 0;
	unsigned long maskValue = 0;


	status = EApiLibInitialize();
	if (EAPI_STATUS_SUCCESS != status)
	{
		printf("EApiLibInitialize() failed, error code: 0x%lX.\n", status);
		return -1;
	}
	else
	{
		printf("EApiLibInitialize() OK.\n");
	}

	status = EApiGPIOGetDirectionCaps(EAPI_ID_GPIO_BANK00, &Inputs, &Outputs);
	if (EAPI_STATUS_SUCCESS != status)
	{
		printf("EApiGPIOGetDirectionCaps() failed, error code: 0x%lX.\n", status);
		return -1;
	}
	else
	{
		printf("GPIO could change as input pins mask is: 0x%lX\n", Inputs);
		printf("GPIO could change as output pins mask is: 0x%lX\n", Outputs);
	}
	

	done = 0;
	while (! done) {
		show_menu();
		if (scanf("%i", &op) <= 0)
			op = -1;
		
		switch (op) {
		case 0:
			done = 1;
			continue;

		case 1:		
			status = EApiGPIOGetDirection(EAPI_ID_GPIO_BANK00, 0xFF, &maskValue);
			if (EAPI_STATUS_SUCCESS != status)
			{
				printf("Get Direction failed, error code: 0x%lX.\n", status);
				status = -1;
				done = 1;
				continue;
			}
			else
			{
				printf("GPIO 0 ~ 7 Direction Mask is (0:Output, 1:Input): 0x%lX\n", maskValue);
			}
			break;

		case 2:	
			printf("Please input which pin direction you want to set (0 ~ 7: pin0 ~ pin7):\n");		
			if (scanf("%i", &input) <= 0)
				input = 0;	
			id = (unsigned long) input;
			if( (id > 7) || (id < 0) )
			{
				id = 0;
			}
			
			switch(id)
			{
			case 0: id = EAPI_GPIO_ID0; break;
			case 1: id = EAPI_GPIO_ID1; break;
			case 2: id = EAPI_GPIO_ID2; break;
			case 3: id = EAPI_GPIO_ID3; break;
			case 4: id = EAPI_GPIO_ID4; break;
			case 5: id = EAPI_GPIO_ID5; break;
			case 6: id = EAPI_GPIO_ID6; break;
			case 7: id = EAPI_GPIO_ID7; break;
			default: break;
			}
			
			printf("Please input the value you want to set (0: Output, 1:Input):\n");
			if (scanf("%i", &input) <= 0)
				input = 0;
			maskValue = (unsigned long) input;
			
			if( (maskValue != 0) && (maskValue != 1) )
			{
				maskValue = 0;
			}			
			
			status = EApiGPIOSetDirection(id, 1, maskValue);
			if (EAPI_STATUS_SUCCESS != status)
			{
				printf("EApiGPIOSetDirection failed, error code: 0x%lX.\n", status);
				status = -1;
				done = 1;
				continue;
			}
			else
			{
				printf("Set GPIO %ld as %s OK.\n", id, maskValue?"INPUT":"OUTPUT");
			}			
			break;
			
		case 3:	
			printf("Please input which pins direction mask you want to set (HEX):\n");		
			if (scanf("%x", &input) <= 0)
				input = 0xFF;	
			mask = (unsigned long) input;
			mask &= 0xFF;
				
			printf("Please input the value mask you want to set (0: Output, 1:Input) (HEX):\n");		
			if (scanf("%x", &input) <= 0)
				input = 0x0F;
			maskValue = (unsigned long) input;

			maskValue &= 0xFF;				
			
			status = EApiGPIOSetDirection(EAPI_ID_GPIO_BANK00, mask, maskValue);
			if (EAPI_STATUS_SUCCESS != status)
			{
				printf("EApiGPIOSetDirection failed, error code: 0x%lX.\n", status);
				status = -1;
				done = 1;
				continue;
			}
			else
			{
				printf("Set GPIO pins direction (mask is: 0x%lX) as 0x%lX OK.\n", mask, maskValue);
			}			
			break;

		case 4:		
			status = EApiGPIOGetLevel(EAPI_ID_GPIO_BANK00, 0xFF, &maskValue);
			if (EAPI_STATUS_SUCCESS != status)
			{
				printf("Get Level failed, error code: 0x%lX.\n", status);
				status = -1;
				done = 1;
				continue;
			}
			else
			{
				printf("GPIO 0 ~ 7 Level Mask is (0:Low, 1:High): 0x%lX\n", maskValue);
			}
			break;

		case 5:	
			printf("Please input which pin level you want to set (0 ~ 7: pin0 ~ pin7):\n");		
			if (scanf("%i", &input) <= 0)
				input = 0;	
			id = (unsigned long) input;
			if( (id > 7) || (id < 0) )
			{
				id = 0;
			}
			
			switch(id)
			{
			case 0: id = EAPI_GPIO_ID0; break;
			case 1: id = EAPI_GPIO_ID1; break;
			case 2: id = EAPI_GPIO_ID2; break;
			case 3: id = EAPI_GPIO_ID3; break;
			case 4: id = EAPI_GPIO_ID4; break;
			case 5: id = EAPI_GPIO_ID5; break;
			case 6: id = EAPI_GPIO_ID6; break;
			case 7: id = EAPI_GPIO_ID7; break;
			default: break;
			}
			
			printf("Please input the value you want to set (0: Low, 1:High):\n");
			if (scanf("%i", &input) <= 0)
				input = 0;
			maskValue = (unsigned long) input;
			
			if( (maskValue != 0) && (maskValue != 1) )
			{
				maskValue = 0;
			}			
			
			status = EApiGPIOSetLevel(id, 1, maskValue);
			if (EAPI_STATUS_SUCCESS != status)
			{
				printf("EApiGPIOSetLevel failed, error code: 0x%lX.\n", status);
				status = -1;
				done = 1;
				continue;
			}
			else
			{
				printf("Set GPIO %ld as %s OK.\n", id, maskValue?"HIGH":"LOW");
			}			
			break;

		case 6:	
			printf("Please input which pins level mask you want to set (HEX):\n");		
			if (scanf("%x", &input) <= 0)
				input = 0xFF;	
			mask = (unsigned long) input;	
			
			mask &= 0xFF;
				
			printf("Please input the value mask you want to set (0: Low, 1:High) (HEX):\n");		
			if (scanf("%x", &input) <= 0)
				input = 0x0F;
			maskValue = (unsigned long) input;
				
			maskValue &= 0xFF;				
				
			status = EApiGPIOSetLevel(EAPI_ID_GPIO_BANK00, mask, maskValue);
			if (EAPI_STATUS_SUCCESS != status)
			{
				printf("EApiGPIOSetLevel failed, error code: 0x%lX.\n", status);
				status = -1;
				done = 1;
				continue;
			}
			else
			{
				printf("Set GPIO pins level (mask is: 0x%lX) as 0x%lX OK.\n", mask, maskValue);
			}			
			break;
				
		default:
			printf("\nUnknown choice!\n\n");
			continue;
		}

		if (EAPI_STATUS_SUCCESS != status) 
		{
			status = EApiLibUnInitialize();
			if (EAPI_STATUS_SUCCESS != status)
			{
				printf("EApiLibUnInitialize() failed, error code: 0x%lX.\n", status);
				return -1;
			}
			else
			{
				printf("EApiLibUnInitialize() OK.\r\n");
			}	return -1;
		}
	}	

	status = EApiLibUnInitialize();
	if (EAPI_STATUS_SUCCESS != status)
	{
		printf("EApiLibUnInitialize() failed, error code: 0x%lX.\n", status);
		return -1;
	}
	else
	{
		printf("EApiLibUnInitialize() OK.\r\n");
	}	
	
	return 0;
}
