#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "define.h"
#include "REL_DEBUG.H"
#include "REL_EC_API.h"

//Modify Ryan.xin 20120223
int fan_exist_flag[2] = { 0 };

int get_info()
{	
	unsigned long count = 0;
	unsigned long val = 0;

	EApiHWMGetFanCount(&count);
	printf("Fan Count: %ld\n", count);

	val = 0;
	EApiHWMGetCaps(EAPI_ID_HWMON_FAN_CPU, &val);
	if(1 == val)
	{
		fan_exist_flag[0] = 1;
		printf("CPU FAN exist.\n");
	}
	
	val = 0;
	EApiHWMGetCaps(EAPI_ID_HWMON_FAN_SYSTEM, &val);
	if(1 == val)
	{
		fan_exist_flag[1] = 1;
		printf("SYSTEM FAN exist.\n");
	}

	return 0;
}


unsigned char check_fan_exist(int input)
{
	//Modify Ryan.xin 20120223
	if( !((input == 0) || (input == 1)/* || (input == 2)*/) )
	{
		return 0;
	}

	if(fan_exist_flag[input] != 1)
	{
		switch(input)
		{
		case 0:
			printf("CPU FAN not exist.\n");
			break;
		case 1:
			printf("SYSTEM FAN not exist.\n");
			break;
		}
		return 0;
	}

	return 1;
}

unsigned long get_id_num(int input)
{
	unsigned long id;

	switch(input)
	{
	case 0:
		id = EAPI_ID_HWMON_FAN_CPU;
		break;
	case 1:
		id = EAPI_ID_HWMON_FAN_SYSTEM;
		break;
	default:
		id = EAPI_ID_HWMON_FAN_CPU;
		break;
	}

	return id;
}

int get_config()
{
	SUSIFANCONFIG Config;
	int input;
	unsigned long id = 0;

	//Modify Ryan.xin 20120223
	//printf("Please input target FAN NO. (0, 1, 2), (0:CPU_FAN, 1:SYS_FAN, 2:THIRD_FAN):\n");
	printf("Please input target FAN NO. (0, 1), (0:CPU_FAN, 1:SYS_FAN):\n");
	if (scanf("%i", &input) <= 0)
		input = 0;

	if( !check_fan_exist(input) )
	{
		return 0; 
	}
	
	id = (unsigned long)input;

	if( EAPI_STATUS_SUCCESS == EApiSusiFanGetConfigStruct( id, &Config) )
	{
		printf("Config.dwMode: 0x%lX\n",Config.dwMode);
		printf("Config.dwPWM: %ld\n",Config.dwPWM);
		printf("Config.safConfig.dwOpMode: 0x%lX\n",Config.safConfig.dwOpMode);
		printf("Config.safConfig.dwLowStopTemp: %ld\n",Config.safConfig.dwLowStopTemp);
		printf("Config.safConfig.dwLowTemp: %ld\n",Config.safConfig.dwLowTemp);
		printf("Config.safConfig.dwHighTemp: %ld\n",Config.safConfig.dwHighTemp);
		printf("Config.safConfig.dwLowPWM: %ld\n",Config.safConfig.dwLowPWM);
		printf("Config.safConfig.dwHighPWM: %ld\n",Config.safConfig.dwHighPWM);
		printf("Config.safConfig.dwLowRPM: 0x%lx\n",Config.safConfig.dwLowRPM);
		printf("Config.safConfig.dwHighRPM: 0x%lx\n",Config.safConfig.dwHighRPM);
	}
	else
	{
		printf("Get configuration failed!!!\n");
	}
	
	return 0;
}

int set_config()
{
	SUSIFANCONFIG Config = {0};
	int input;
	unsigned long unit = 0;	
	unsigned long mode = 0;
	
	//Modify Ryan.xin 20120223
	printf("Please input target FAN NO. (0, 1), (0:CPU_FAN, 1:SYS_FAN):\n");
	if (scanf("%i", &input) <= 0)
		input = 0;

	unit = (unsigned long)input;	
	if( !check_fan_exist(input) )
	{
		return 0; 
	}

	printf("Please input configuration mode: (0: Off, 1: Full, 2: Manual, 3: Auto)\n");
	scanf("%i", &input);
	mode = (unsigned long)input;
	switch(mode)
	{
	case 0:
		Config.dwMode = SUSI_FAN_MODE_OFF;
		goto SET_FAN_CONF;	
	case 1:
		Config.dwMode = SUSI_FAN_MODE_FULL;
		goto SET_FAN_CONF;	
	case 2:
		Config.dwMode = SUSI_FAN_MODE_MANUAL;
		printf("Please input PWM value: (range: 0 ~ 100)\n");
		scanf("%i", &input);
		Config.dwPWM = (unsigned int)input;
		goto SET_FAN_CONF;
	case 3:
	default:
		Config.dwMode = SUSI_FAN_MODE_AUTO;
		break;
	}

	/*Auto Mode*/
	printf("Please input operation mode: (0: PWM, 1: RPM)\n");
	scanf("%i", &input);
	mode = (unsigned long)input;
	switch(mode)
	{
	case 1:
		Config.safConfig.dwOpMode = SUSI_FAN_OPMODE_RPM;
		printf("Please input low RPM value: (0 ~ 0xFFFF, Hex)\n");	
		scanf("%x", &input);
		Config.safConfig.dwLowRPM= (unsigned int)input;
		printf("Please input high RPM value: (Low ~ 0xFFFF, Hex)\n");	
		scanf("%x", &input);
		Config.safConfig.dwHighRPM = (unsigned int)input;
		break;	
	case 0:
	default:
		Config.safConfig.dwOpMode = SUSI_FAN_OPMODE_PWM;
		printf("Please input low PWM value: (0 ~ 100)\n");
		scanf("%i", &input);
		Config.safConfig.dwLowPWM = (unsigned int)input;
		printf("Please input high PWM value: (Low ~ 100)\n");
		scanf("%i", &input);
		Config.safConfig.dwHighPWM = (unsigned int)input;
		break;
	}

	printf("Please input stop temperature value: (0 ~ 125)\n");
	scanf("%i", &input);
	Config.safConfig.dwLowStopTemp = (unsigned int)input;

	printf("Please input low temperature value: (stop ~ 125)\n");
	scanf("%i", &input);
	Config.safConfig.dwLowTemp = (unsigned int)input;

	printf("Please input high temperature value: (low ~ 125)\n");
	scanf("%i", &input);
	Config.safConfig.dwHighTemp = (unsigned int)input;	
	

SET_FAN_CONF:
	
	if( EAPI_STATUS_SUCCESS == EApiSusiFanSetConfigStruct(unit, &Config) )
	{	
		printf("Set configuration OK.\n");
	}
	else
	{
		printf("Set configuration failed!!!\n");
	}
	
	return 0;
}


void show_menu(void)
{
	printf("\n");
	printf("0) Terminate this program\n");
	printf("1) Get target fan current value\n");	
	printf("2) Get target fan configuration\n");
	printf("3) Set target fan configuration\n");
	printf("Enter your choice: \n");
}

int main( int argc, char *argv[] )
{
	int done, op, input;
	int result = 0;
	unsigned long status = 0;
	unsigned long id = 0;
	unsigned long val = 0;

	status = EApiLibInitialize();
	if (EAPI_STATUS_SUCCESS != status)
	{
		printf("EApiLibInitialize() failed, error code: 0x%lX.\n", status);
		return -1;
	}
	else
	{
		printf("EApiLibInitialize() OK.\n");
	}

	get_info();

	done = 0;
	
	while (!done)
	{
		show_menu();
		
		if (scanf("%i", &op) <= 0)
			op = -1;
		
		switch (op)
		{
		case 0:
			done = 1;
			continue;		
		case 1:
			input = 0;
			//Modify Ryan.xin 20120223
			printf("Please input target FAN NO. (0, 1), (0:CPU_FAN, 1:SYS_FAN):\n");
			if (scanf("%i", &input) <= 0)
			input = 0;

			if( !check_fan_exist(input) )
			{
				continue; 
			}
			
			id = get_id_num(input);
			
			status = EApiBoardGetValue(id, &val);
			if (EAPI_STATUS_SUCCESS != status)
			{
				printf("Get Target Fan failed, error code: 0x%lX.\n", status);
				result = -1;
			}
			else
			{
				printf("Target Fan value: %ld\n", val);
			}			
			break;		
		case 2:
			result = get_config();
			break;
		case 3:
			result = set_config();
			break;
		default:
			printf("\nUnknown choice!\n");
			
		} /*switch (op)*/
		
		if(done != 1 && result < 0) 
		{
			status = EApiLibUnInitialize();
			if (EAPI_STATUS_SUCCESS != status)
			{
				printf("EApiLibUnInitialize() failed, error code: 0x%lX.\n", status);
				return -1;
			}
			else
			{
				printf("EApiLibUnInitialize() OK.\n");
			}
			
			return -1;
		}
		
	} /*while (!done)*/
	
	status = EApiLibUnInitialize();
	if (EAPI_STATUS_SUCCESS != status)
	{
		printf("EApiLibUnInitialize() failed, error code: 0x%lX.\n", status);
		return -1;
	}
	else
	{
		printf("EApiLibUnInitialize() OK.\n");
	}
	
	return 0;
}